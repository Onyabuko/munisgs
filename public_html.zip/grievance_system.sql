-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2025 at 12:54 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grievance_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `grievances`
--

CREATE TABLE `grievances` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `status` enum('pending','in_progress','resolved') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `assigned_admin` int(11) DEFAULT NULL,
  `auto_responded` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `grievances`
--

INSERT INTO `grievances` (`id`, `user_id`, `title`, `category`, `description`, `status`, `created_at`, `assigned_admin`, `auto_responded`) VALUES
(1, 2, 'Bullying', '', 'Yesterday i was bullied by by a year 3 student in nursing', 'resolved', '2025-03-11 13:05:47', 5, 1),
(2, 2, 'Language barrier', '', 'Ever since i joined campus, i have had difficulty in communication with the locals', 'resolved', '2025-03-11 13:24:13', NULL, 0),
(3, 4, 'Hunger', '', 'too much hunger in Arua', 'resolved', '2025-03-11 15:08:51', NULL, 0),
(4, 4, 'Bullying', '', 'I was bullyed by a year 2 student', 'resolved', '2025-03-12 08:02:16', 5, 0),
(5, 7, 'Health issue', '', 'I\'m having ulcers, i need your help', 'resolved', '2025-03-12 08:46:37', NULL, 1),
(6, 7, 'Health issue', '', 'I\'m have ulcers and they don\'t have medicine at the clinic', 'resolved', '2025-03-12 09:33:07', NULL, 1),
(7, 4, 'Bullying', 'bullying', 'I was bullied by a year 3 nursing student', 'resolved', '2025-03-12 09:50:43', 5, 0),
(8, 7, 'Hostel saniatation', 'hostel', 'Hostels are very dirty, we need you to intervene', 'in_progress', '2025-03-12 10:07:11', NULL, 0),
(9, 7, 'Hunger', 'health', 'I\'m unable to locate any restaurants during evening hours and this has greatly affected my health (ulcers)', 'resolved', '2025-03-14 04:07:41', 6, 1),
(10, 7, 'Delay of marks on the portal', 'education', 'It\'s been 2 months ever since the Dean of Faculty told us that our marks would be uploaded on the portal, we need feedback on this as some of us are unaable to submit our testimonials for job requests due to missing marks on the portal', 'resolved', '2025-03-14 04:10:04', NULL, 0),
(11, 4, 'Water inadequance', 'hostel', 'we are having problems of water shrtage, we request the admin to intervene', 'pending', '2025-03-17 11:46:36', 8, 0);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `grievance_id` int(11) DEFAULT NULL,
  `sender` enum('admin','student') DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0,
  `file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `grievance_id`, `sender`, `message`, `created_at`, `is_read`, `file`) VALUES
(1, 3, 'admin', 'You can share your mobile money number and i send you lunch', '2025-03-12 03:13:35', 1, NULL),
(2, 3, 'student', 'Okay, my number is 0771276658', '2025-03-12 04:13:15', 1, NULL),
(3, 3, 'admin', 'Y\'ello, you have recieved Ugx. 200,000 from Dean of Students. Your balance is Ugx. 201,000', '2025-03-12 04:24:00', 1, NULL),
(4, 4, 'admin', 'tell me his name', '2025-03-12 08:04:29', 1, NULL),
(5, 4, 'student', 'josh', '2025-03-12 08:06:40', 1, NULL),
(6, 4, 'admin', 'wait is that the josh from MIT?', '2025-03-12 08:08:45', 1, NULL),
(7, 2, 'admin', 'Don\'t worry, you\'ll learn the language', '2025-03-12 08:21:58', 0, NULL),
(8, 4, 'student', 'yes, he\'s the one', '2025-03-12 09:51:09', 1, NULL),
(9, 7, 'admin', 'Ohh i will deal with him', '2025-03-12 09:58:28', 1, NULL),
(10, 4, 'admin', 'I will deal with him accordingly, don\'t worry', '2025-03-12 10:00:08', 0, NULL),
(11, 8, 'admin', 'I will reach out to the hostel manager', '2025-03-12 11:53:30', 1, NULL),
(12, 8, 'student', 'Okay, thank you', '2025-03-12 12:29:57', 1, NULL),
(13, 7, 'admin', 'Is he still bullying you?', '2025-03-14 15:47:09', 1, NULL),
(14, 7, 'student', 'No, thank you for your service', '2025-03-14 15:48:47', 1, NULL),
(15, 7, 'admin', 'You are welcome', '2025-03-14 15:50:04', 0, NULL),
(16, 10, 'admin', 'Don\'t worry, i will reach out to the dean of faculty. In which faculty are you specifically?', '2025-03-14 15:53:45', 1, NULL),
(17, 10, 'student', 'Okay, can i know when exactly?', '2025-03-14 18:36:54', 1, NULL),
(18, 1, 'admin', 'API Error: You exceeded your current quota, please check your plan and billing details. For more information on this error, read the docs: https://platform.openai.com/docs/guides/error-codes/api-errors.', '2025-03-15 06:45:53', 1, NULL),
(19, 5, 'admin', 'API Error: You exceeded your current quota, please check your plan and billing details. For more information on this error, read the docs: https://platform.openai.com/docs/guides/error-codes/api-errors.', '2025-03-15 06:45:54', 1, NULL),
(20, 6, 'admin', 'API Error: You exceeded your current quota, please check your plan and billing details. For more information on this error, read the docs: https://platform.openai.com/docs/guides/error-codes/api-errors.', '2025-03-15 06:45:55', 1, NULL),
(21, 9, 'admin', 'API Error: You exceeded your current quota, please check your plan and billing details. For more information on this error, read the docs: https://platform.openai.com/docs/guides/error-codes/api-errors.', '2025-03-15 06:45:57', 1, NULL),
(22, 10, 'admin', 'checkiing whether u can recieve this image', '2025-03-15 16:00:17', 1, 'uploads/67d5a411b5e56_Screenshot (423).png'),
(23, 10, 'student', 'Yes I have recieved it', '2025-03-15 16:03:04', 1, NULL),
(24, 10, 'admin', 'Subject: Response to Your Concern Regarding Delayed Marks on the Portal\r\n\r\nDear Benard,\r\n\r\nThank you for bringing the issue of the delayed marks on the portal to our attention. We sincerely appreciate your patience and understand the importance of these marks, especially as they relate to your upcoming career opportunities.\r\n\r\nWe regret the inconvenience this delay has caused and acknowledge the impact it may have on your plans. Please rest assured that we are treating this matter with urgency. Our team is working diligently to resolve the issue, and we are currently addressing the technical and procedural challenges that have led to this delay.\r\n\r\nWe expect the marks to be updated by [Expected Date] and will ensure this is resolved as swiftly as possible. In the meantime, if you require immediate assistance with testimonials or any related documentation, please contact us directly at [Contact Information]. We are happy to provide any necessary verification or interim documents to support your applications.\r\n\r\nThank you for your understanding. Should you have any further concerns, please do not hesitate to reach out.\r\n\r\nWarm regards,\r\n\r\nJessy\r\nAsst. Dean', '2025-03-17 11:39:53', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','admin') DEFAULT 'student',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `admin_category` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`, `admin_category`) VALUES
(1, 'Cal', 'dukecalvin77@gmail.com', '$2y$10$0WNlyeqqySktdDByX0UpPOouKqE3r0l/U/8vIxBZpO0DOm4BaxE/y', 'student', '2025-03-11 12:49:20', NULL),
(2, 'Isaac', 'onyabukoisaac@gmail.com', '$2y$10$MArFQTHP8hPNkDhsEKNthu2Hi6AluhiJ305L2DDGOBu.rGd2dCBBG', 'student', '2025-03-11 12:53:17', NULL),
(3, 'Main Admin', '2201200214@muni.ac.ug', '$2y$10$kF02DeNPRqNqGatXY2cK1.ZDFxKY6HyPuBEiGEj.j7Fbg0UQ49W.O', 'admin', '2025-03-11 14:26:30', 'main'),
(4, 'Ismail', '2201200201@gmail.com', '$2y$10$DBMdEsxDwF7hT3UMPpU/nutgOhyF.4pzGl6J1Fk/nduyB5J52DXRK', 'student', '2025-03-11 15:08:01', NULL),
(5, 'Julio Julio', 'julio@muni.ac.ug', '$2y$10$L3qRrdapDspQ./88qy/BEeIYIaZI7NYOP.daaCkSPjpIIyUmuDkci', 'admin', '2025-03-12 04:48:58', 'bullying'),
(6, 'Joseph', 'joseph@gmail.com', '$2y$10$AN08qSEpCe7X9tOXkArtqe4apeSZgPMGxwlHN7aHZYLlKaBP6eyzS', 'admin', '2025-03-12 08:10:18', 'health'),
(7, 'Benard', 'benard@gmail.com', '$2y$10$jXBjxfFbZ/Wbp5qPcmPxRu8bAjdD7fwcn2Hc.wvfn2lIHeCa5GvpS', 'student', '2025-03-12 08:45:31', NULL),
(8, 'musa', 'musa@gmail.com', '$2y$10$aQtIknmGSNru.jomdZgAwu5RFEFMdzSZ5dkwTz994zNhVQsMTPt6O', 'admin', '2025-03-12 10:03:41', 'hostel'),
(9, 'derrick', 'derrick@gmail.com', '$2y$10$Jpd9Eklb32ypPNgDzMwri.qrl.6XVyND9qaQBng9hQaOrqeFKoU0.', 'student', '2025-03-12 12:16:43', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `grievances`
--
ALTER TABLE `grievances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `grievance_id` (`grievance_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `grievances`
--
ALTER TABLE `grievances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `grievances`
--
ALTER TABLE `grievances`
  ADD CONSTRAINT `grievances_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`grievance_id`) REFERENCES `grievances` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
