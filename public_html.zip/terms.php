<?php
// terms.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'includes/config.php';
include 'includes/helpers.php';
?>
<?php include 'includes/header.php'; ?>

<div class="container py-5" style="margin-top: 5rem;">
  <div class="card shadow-sm">
    <div class="card-body">
      <h2 class="mb-4">Terms &amp; Conditions</h2>

      <p>Welcome to the Muni Student Grievance System. By registering and using our platform, you agree to the following terms and conditions. Please read them carefully.</p>

      <h5 class="mt-4">1. Acceptance of Terms</h5>
      <p>By creating an account, you confirm that you have read, understood, and agree to be bound by these Terms &amp; Conditions.</p>

      <h5 class="mt-4">2. User Responsibilities</h5>
      <ul>
        <li>You must provide accurate, current, and complete information when registering.</li>
        <li>You are responsible for maintaining the confidentiality of your login credentials.</li>
        <li>You agree not to use the platform for any unlawful or prohibited activities.</li>
      </ul>

      <h5 class="mt-4">3. Privacy &amp; Data</h5>
      <p>We respect your privacy. All personal data is stored securely and used only for the purpose of managing grievances. See our <a href="privacy.php">Privacy Policy</a> for full details.</p>

      <h5 class="mt-4">4. Grievance Submission</h5>
      <p>All grievances submitted must be truthful and respectful. Misuse of the system to submit false or malicious complaints may result in account suspension.</p>

      <h5 class="mt-4">5. Automated Responses</h5>
      <p>During off‑hours or if an admin hasn’t responded within 15 minutes, our AI helper may send an automated acknowledgment. This does not replace a direct admin response.</p>

      <h5 class="mt-4">6. Intellectual Property</h5>
      <p>All content, design, and code of this platform are the property of Muni University. You may not reproduce or distribute any part without permission.</p>

      <h5 class="mt-4">7. Limitation of Liability</h5>
      <p>We strive to keep the system available 24/7, but we do not guarantee uninterrupted service. We are not liable for any indirect or consequential damages arising from use of the platform.</p>

      <h5 class="mt-4">8. Modifications to Terms</h5>
      <p>We may update these Terms &amp; Conditions at any time. Continued use of the platform after changes constitutes acceptance of the new terms.</p>

      <h5 class="mt-4">9. Contact Us</h5>
      <p>If you have questions about these Terms, please contact us at <a href="mailto:support@munisgs.online">support@munisgs.online</a>.</p>

      <div class="text-center mt-5">
        <a href="register.php" class="btn btn-gradient px-4">Accept &amp; Continue</a>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
