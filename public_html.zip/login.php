<?php include 'includes/header.php'; ?>
<br>
<div class="container min-vh-100 d-flex align-items-center justify-content-center">
  <div class="card mx-auto p-5" style="width: 100%; max-width: 400px;">
  <div class="text-center mb-5">
          <img src="assets/images/image.png" alt="Logo" class="login-logo animate__animated animate__bounceIn">
          <!-- <h2 class="mt-3 text-gradient">Muni Students Grievance System</h2>
          <p class="text-muted">Secure Access Portal</p> -->
        </div>
    <h2 class="text-center mb-4">Welcome Back! 👋</h2>
    <?php if(isset($_SESSION['error'])): ?>
      <div class="alert alert-danger">
        <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
      </div>
    <?php endif; ?>
    <form id="loginForm" action="includes/auth.php" method="POST">
      <!-- New: Choose login type -->
      <div class="mb-3">
        <select name="login_type" class="form-select" required>
          <option value="">Select Login Type</option>
          <option value="student">Student</option>
          <option value="dean">Dean of Students</option>
          <option value="counselor">Counselor</option>
        </select>
      </div>
      <div class="mb-3">
        <input type="email" name="email" class="form-control" placeholder="Enter your email address" required>
      </div>
      <div class="mb-4">
        <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
      </div>
      <button type="submit" name="login" class="btn-gradient w-100">Login</button>
    </form>
    <div class="text-center mt-3">
      <p class="text-muted">New here? <a href="register.php" class="text-primary">Create account</a></p>
    </div>
  </div>
</div>
<style>
  .login-logo {
  width: 25vh;
  filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1));
  border-radius: 90%;
}
</style>
