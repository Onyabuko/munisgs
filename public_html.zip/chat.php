<?php
include_once 'includes/config.php';
include_once 'includes/auth.php';
//include_once 'auto_respond.php'; // Include auto-respond logic

// Check for grievance_id in the query string
if (!isset($_GET['grievance_id'])) {
    header("Location: dashboard.php");
    exit;
}

$grievance_id = $_GET['grievance_id'];

// Load grievance details
$stmt = $pdo->prepare("SELECT * FROM grievances WHERE id = ?");
$stmt->execute([$grievance_id]);
$grievance = $stmt->fetch();

if (!$grievance) {
    echo '<div class="container mt-5"><div class="alert alert-danger">Invalid grievance ID. <a href="dashboard.php" class="alert-link">Go back to Dashboard</a></div></div>';
    exit;
}

// For students: ensure they own the grievance
if ($_SESSION['user_role'] === 'student' && $grievance['user_id'] != $_SESSION['user_id']) {
    echo '<div class="container mt-5"><div class="alert alert-danger">Access Denied: You are not authorized to view this grievance. <a href="dashboard.php" class="alert-link">Go back to Dashboard</a></div></div>';
    exit;
}

// For sub-admins: ensure the grievance category matches their assigned category
if ($_SESSION['user_role'] === 'admin' && $_SESSION['admin_category'] !== 'main') {
    if ($grievance['category'] !== $_SESSION['admin_category']) {
        echo '<div class="container mt-5"><div class="alert alert-danger">Access Denied: You do not have permission to view this grievance. <a href="admin/dashboard.php" class="alert-link">Go back to Dashboard</a></div></div>';
        exit;
    }
}

// Process message submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $message = trim($_POST['message']);
    $file_path = null;
    $voicenote_path = null;

    // Process file upload
    if (isset($_FILES['chat_file']) && $_FILES['chat_file']['error'] === 0) {
        $allowed = [
            "jpg" => "image/jpeg",
            "jpeg" => "image/jpeg",
            "png" => "image/png",
            "gif" => "image/gif",
            "pdf" => "application/pdf",
            "doc" => "application/msword",
            "docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        ];
        $filename = $_FILES['chat_file']['name'];
        $filetype = mime_content_type($_FILES['chat_file']['tmp_name']);
        $filesize = $_FILES['chat_file']['size'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (!array_key_exists($ext, $allowed) || $allowed[$ext] !== $filetype) {
            $_SESSION['error'] = "Invalid file format. Allowed: jpg, jpeg, png, gif, pdf, doc, docx.";
        } elseif ($filesize > 5 * 1024 * 1024) {
            $_SESSION['error'] = "File size exceeds 5MB limit.";
        } else {
            if (!file_exists("uploads")) {
                mkdir("uploads", 0777, true);
            }
            $newfilename = uniqid() . "_" . basename($filename);
            $destination = "uploads/" . $newfilename;
            if (move_uploaded_file($_FILES['chat_file']['tmp_name'], $destination)) {
                $file_path = $destination;
            } else {
                $_SESSION['error'] = "Error uploading file.";
            }
        }
    }

    // Process voicenote upload
    if (isset($_FILES['voicenote']) && $_FILES['voicenote']['error'] === 0) {
        $allowed_audio = ['mp3' => 'audio/mpeg', 'wav' => 'audio/wav', 'ogg' => 'audio/ogg'];
        $filename = $_FILES['voicenote']['name'];
        $filetype = mime_content_type($_FILES['voicenote']['tmp_name']);
        $filesize = $_FILES['voicenote']['size'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (!array_key_exists($ext, $allowed_audio) || $allowed_audio[$ext] !== $filetype) {
            $_SESSION['error'] = "Invalid voicenote format. Allowed: mp3, wav, ogg.";
        } elseif ($filesize > 10 * 1024 * 1024) {
            $_SESSION['error'] = "Voicenote size exceeds 10MB limit.";
        } else {
            $newfilename = uniqid() . "_voicenote_" . basename($filename);
            $destination = "uploads/" . $newfilename;
            if (move_uploaded_file($_FILES['voicenote']['tmp_name'], $destination)) {
                $voicenote_path = $destination;
            } else {
                $_SESSION['error'] = "Error uploading voicenote.";
            }
        }
    }

    if (!isset($_SESSION['error']) && ($message || $file_path || $voicenote_path)) {
        $sender = $_SESSION['user_role'];
        $stmt = $pdo->prepare("INSERT INTO messages (grievance_id, sender, message, file, voicenote) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$grievance_id, $sender, $message, $file_path, $voicenote_path]);

        // Update grievance status
        $new_status = ($sender === 'admin') ? 'resolved' : 'in_progress';
        $stmt = $pdo->prepare("UPDATE grievances SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $grievance_id]);

        $_SESSION['message'] = "Message sent.";
        header("Location: chat.php?grievance_id=" . $grievance_id);
        exit;
    }
}

// Handle error logging
if (!empty($_SESSION['error'])) {
    $log_dir = __DIR__ . '/logs';
    $log_file = $log_dir . '/errors.log';
    
    // Create logs directory if it doesn't exist
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0777, true);
    }
    
    // Check if log file is writable, fallback to default error log if not
    if (is_writable($log_dir) && (!file_exists($log_file) || is_writable($log_file))) {
        error_log($_SESSION['error'] . PHP_EOL, 3, $log_file);
    } else {
        error_log($_SESSION['error']);
    }
}

// Mark unread messages as read
$stmt = $pdo->prepare("UPDATE messages SET is_read = 1 WHERE grievance_id = ? AND sender = ? AND is_read = 0");
$stmt->execute([$grievance_id, ($_SESSION['user_role'] === 'student') ? 'admin' : 'student']);

// Fetch all messages, ordered by id ASC
$stmt = $pdo->prepare("SELECT * FROM messages WHERE grievance_id = ? ORDER BY id ASC");
$stmt->execute([$grievance_id]);
$messages = $stmt->fetchAll();


?>

<?php include 'includes/header.php'; ?>
<br><br>
<div class="d-flex flex-column min-vh-20 bg-light">
   

    <!-- Centered Chat Container -->
    <div class="chat-container mx-auto d-flex flex-column" style="width: 100%; max-width: 800px; height: 700px; ">
        <!-- Header -->
        <div class="bg-success text-white p-3 d-flex align-items-center">
            <a href="<?php echo ($_SESSION['user_role'] === 'admin') ? 'admin/dashboard.php' : 'dashboard.php'; ?>" class="text-white me-3">
                <i class="bi bi-arrow-left"></i>
            </a>
            <div>
                <h5 class="mb-0"><?= htmlspecialchars($grievance['title'] ?: 'Untitled Grievance') ?></h5>
                <small>Category: <?= htmlspecialchars($grievance['category'] ?: 'General') ?> | 
                    <span class="badge bg-<?php echo statusColor($grievance['status']); ?>">
                        <?php echo ucfirst($grievance['status']); ?>
                    </span>
                </small>
            </div>
        </div>

        <!-- Chat Area -->
        <div class="chat-box flex-grow-1  p-3 overflow-auto" style="background: lightgrey; min-vh-20  !important;">
            <!-- Initial Grievance Description -->
            <?php if (empty($messages)): ?>
                <div class="d-flex justify-content-start mb-3">
                    <div class="chat-message bg-light p-3 rounded shadow-sm" style="max-width: 70%;">
                        <small class="text-muted">System</small>
                        <div class="chat-text"><?php echo nl2br(htmlspecialchars($grievance['description'])); ?></div>
                        <small class="text-muted"><?php echo date('M d, Y H:i', strtotime($grievance['created_at'])); ?></small>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Messages -->
            <?php foreach ($messages as $msg): ?>
        <div class="d-flex <?php echo $msg['sender'] === $_SESSION['user_role'] ? 'justify-content-end' : 'justify-content-start'; ?> mb-3">
                    <div class="chat-message p-2 rounded shadow-sm <?php echo $msg['sender'] === $_SESSION['user_role'] ? 'bg-success text-white' : 'bg-white'; ?>" style="max-width: 80%;">
                        <small class="fw-bold"><?php echo ucfirst($msg['sender']); ?></small>
                        <?php if ($msg['message']): ?>
                            <div class="chat-text"><?php echo nl2br(htmlspecialchars($msg['message'])); ?></div>
                        <?php endif; ?>

                        <!-- Display Image -->
                        <?php if ($msg['file'] && in_array(strtolower(pathinfo($msg['file'], PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'gif'])): ?>
                            <a href="<?php echo htmlspecialchars($msg['file']); ?>" target="_blank">
                                <img src="<?php echo htmlspecialchars($msg['file']); ?>" class="img-fluid rounded my-2" style="max-width: 200px;" alt="Attachment">
                            </a>
                        <?php endif; ?>

                        <!-- Display Document -->
                        <?php if ($msg['file'] && in_array(strtolower(pathinfo($msg['file'], PATHINFO_EXTENSION)), ['pdf', 'doc', 'docx'])): ?>
                            <div class="my-2">
                                <a href="<?php echo htmlspecialchars($msg['file']); ?>" target="_blank" class="text-decoration-none">
                                    <i class="bi bi-file-earmark-text"></i> <?php echo basename($msg['file']); ?>
                                </a>
                            </div>
                        <?php endif; ?>

                        <!-- Display Voicenote -->
                        <?php if ($msg['voicenote']): ?>
                            <div class="my-2">
                                <audio controls class="w-100">
                                    <source src="<?php echo htmlspecialchars($msg['voicenote']); ?>" type="audio/<?php echo pathinfo($msg['voicenote'], PATHINFO_EXTENSION); ?>">
                                    Your browser does not support the audio element.
                                </audio>
                            </div>
                        <?php endif; ?>

                        <small class="d-block text-muted"><?php echo date('M d, Y H:i', strtotime($msg['created_at'])); ?></small>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Message Input Form -->
        <div class="input-form bg-white p-2 border-top" style="">
            <form method="POST" id="responseForm" enctype="multipart/form-data">
                <div class="input-group">
                    <textarea name="message" style="padding:14px !important;" class="form-control" placeholder="Type a message..." rows="1" style="resize: none;"></textarea>
                    <input type="file" name="chat_file" id="chat_file" class="d-none" accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx">
                    <input type="file" name="voicenote"  id="voicenote" class="d-none" accept=".mp3,.wav,.ogg">
                    <button type="button" id="attachFile" style="padding:14px !important;"class="btn btn-outline-secondary" title="Attach File">
                        <i class="bi bi-paperclip"></i>
                    </button>
                    <button type="button" id="startRecording" style="padding:12px !important;" class="btn btn-outline-secondary" title="Record Voicenote">
                        <i class="bi bi-mic-fill"></i>
                    </button>
                    <button type="button" id="stopRecording" style="padding:12px !important;" class="btn btn-outline-danger d-none" title="Stop Recording">
                        <i class="bi bi-stop-fill"></i>
                    </button>
                    <button type="button" id="clearMedia" style="padding:12px !important;"class="btn btn-outline-danger d-none" title="Clear Attachment">
                        <i class="bi bi-trash"></i>
                    </button>
                    <button type="submit" style="padding:0px 19px 0px 19px"  name="send_message" class="btn btn-success">
                        <i class="bi bi-send"></i>
                    </button>
                </div>
                <audio id="audioPlayback" controls class="w-100 mt-2 d-none"></audio>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap Icons and Custom Styles -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<!-- Include lamejs for MP3 conversion -->
<script src="https://cdn.jsdelivr.net/npm/lamejs@1.2.1/lame.min.js"></script>
<style>
/* Ensure full viewport height and centered layout */
.min-vh-100 {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* Centered chat container with responsive width */
.chat-container {
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

/* Chat box with auto height */
.chat-box {
    overflow-y: auto;
    flex-grow: 1;
    background-size: cover;
    
}

/* Message styling */
.chat-message {
    word-wrap: break-word;
    position: relative;
    
}
.bg-success.text-white {
    border-radius: 10px 10px 0 0;
}
.bg-white {
    border-radius: 10px 10px 0 0;
}
.input-group textarea {
    border-radius: 20px;
    
}
.input-group button {
    border-radius: 20px;
}

/* Badge colors */
.badge.bg-warning { background-color: #ffc107; }
.badge.bg-info { background-color: #17a2b8; }
.badge.bg-success { background-color: #28a745; }

/* Responsive adjustments */
@media (max-width: 576px) {
    .chat-container {
        margin: 0;
        width: 100%;
        height: 100vh;
        margin-bottom:-9rem;
         height: 100vh;
        
    }
    .input-form{
         margin-bottom: rem;
    }
    .chat-message {
        max-width: 85%;
    }
    .chat-box {
        padding: 10px;
       height:30rem;
        margin-bottom: 80% !important;
    }
    .input-group button {
        padding: 8px;
       
    }
    .input-group textarea {
        font-size: 17px;
    }
}

@media (min-width: 577px) {
    .chat-container {
        width: 80%;
        max-width: 800px;
        margin: 10px auto 
        
    }
    .chat-message {
        max-width: 75%;
    }
}
</style>

<script>
let mediaRecorder;
let audioChunks = [];
const startButton = document.getElementById('startRecording');
const stopButton = document.getElementById('stopRecording');
const clearMediaButton = document.getElementById('clearMedia');
const audioPlayback = document.getElementById('audioPlayback');
const voicenoteInput = document.getElementById('voicenote');
const fileInput = document.getElementById('chat_file');
const attachFileButton = document.getElementById('attachFile');

// Function to convert WAV to MP3 using lamejs
async function convertToMP3(wavBlob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = function(event) {
            const arrayBuffer = event.target.result;
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            
            audioContext.decodeAudioData(arrayBuffer, function(audioBuffer) {
                // Convert stereo to mono if necessary
                const numberOfChannels = 1; // Mono
                const sampleRate = 44100; // Standard sample rate
                const length = audioBuffer.length;
                const monoBuffer = new Float32Array(length);
                
                // Mix stereo to mono by averaging channels
                for (let i = 0; i < length; i++) {
                    let sum = 0;
                    for (let channel = 0; channel < audioBuffer.numberOfChannels; channel++) {
                        sum += audioBuffer.getChannelData(channel)[i];
                    }
                    monoBuffer[i] = sum / audioBuffer.numberOfChannels;
                }

                // Convert Float32Array to Int16Array for lamejs
                const int16Data = new Int16Array(length);
                for (let i = 0; i < length; i++) {
                    int16Data[i] = monoBuffer[i] * 32767; // Convert to 16-bit PCM
                }

                // Use lamejs to encode to MP3
                const mp3encoder = new lamejs.Mp3Encoder(numberOfChannels, sampleRate, 128); // 128 kbps
                const mp3Data = [];
                const sampleBlockSize = 1152; // MP3 frame size

                for (let i = 0; i < length; i += sampleBlockSize) {
                    const sampleChunk = int16Data.subarray(i, i + sampleBlockSize);
                    const mp3buf = mp3encoder.encodeBuffer(sampleChunk);
                    if (mp3buf.length > 0) {
                        mp3Data.push(mp3buf);
                    }
                }

                const mp3buf = mp3encoder.flush();
                if (mp3buf.length > 0) {
                    mp3Data.push(mp3buf);
                }

                const mp3Blob = new Blob(mp3Data, { type: 'audio/mp3' });
                resolve(mp3Blob);
            }, reject);
        };
        reader.onerror = reject;
        reader.readAsArrayBuffer(wavBlob);
    });
}

startButton.addEventListener('click', async () => {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        
        mediaRecorder.ondataavailable = (event) => {
            audioChunks.push(event.data);
        };

        mediaRecorder.onstop = async () => {
            const wavBlob = new Blob(audioChunks, { type: 'audio/wav' });
            try {
                const mp3Blob = await convertToMP3(wavBlob);
                const audioUrl = URL.createObjectURL(mp3Blob);
                audioPlayback.src = audioUrl;
                audioPlayback.classList.remove('d-none');
                clearMediaButton.classList.remove('d-none');
                stopButton.classList.add('d-none');
                startButton.classList.remove('d-none');

                const audioFile = new File([mp3Blob], `voicenote_${Date.now()}.mp3`, { type: 'audio/mp3' });
                const dataTransfer = new DataTransfer();
                dataTransfer.items.add(audioFile);
                voicenoteInput.files = dataTransfer.files;

                audioChunks = [];
            } catch (error) {
                alert('Error converting audio to MP3.');
                console.error(error);
            }
        };

        mediaRecorder.start();
        startButton.classList.add('d-none');
        stopButton.classList.remove('d-none');
        fileInput.value = '';
    } catch (err) {
        alert('Microphone access denied or not available.');
        console.error(err);
    }
});

stopButton.addEventListener('click', () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
    }
});

clearMediaButton.addEventListener('click', () => {
    audioPlayback.classList.add('d-none');
    audioPlayback.src = '';
    voicenoteInput.value = '';
    fileInput.value = '';
    clearMediaButton.classList.add('d-none');
    startButton.classList.remove('d-none');
    stopButton.classList.add('d-none');
});

attachFileButton.addEventListener('click', () => {
    fileInput.click();
});

fileInput.addEventListener('change', () => {
    if (fileInput.files.length > 0) {
        clearMediaButton.classList.remove('d-none');
        voicenoteInput.value = '';
        audioPlayback.classList.add('d-none');
        audioPlayback.src = '';
    }
});
</script>
