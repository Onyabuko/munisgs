<?php
// dashboard.php (Student)

include 'includes/config.php';
include 'includes/auth.php';
include 'includes/helpers.php';

// Ensure the user is a student
if ($_SESSION['user_role'] !== 'student') {
    header("Location: index.php");
    exit;
}

// Determine filter
$filter = $_GET['filter'] ?? 'all'; // all|pending|in_progress|resolved

// Build WHERE clause
$whereClauses = ["user_id = ?"];
$params = [$_SESSION['user_id']];

if (in_array($filter, ['pending','in_progress','resolved'])) {
    $whereClauses[] = "status = ?";
    $params[] = $filter;
}
$whereSQL = 'WHERE ' . implode(' AND ', $whereClauses);

// Fetch counts
$countStmt = $pdo->prepare("SELECT 
    COUNT(*) as total,
    SUM(status='pending') as pending,
    SUM(status='in_progress') as in_progress,
    SUM(status='resolved') as resolved
  FROM grievances
  $whereSQL
");
$countStmt->execute($params);
$counts = $countStmt->fetch();

// Fetch grievances
$listStmt = $pdo->prepare("
    SELECT * FROM grievances
    $whereSQL
    ORDER BY created_at DESC
");
$listStmt->execute($params);
$grievances = $listStmt->fetchAll();

include 'includes/header.php';
?>

<div class="container-fluid px-3 px-md-5 py-4">
  <h2 class="mb-4 text-center">My Grievances</h2>

  <!-- Summary Cards -->
  <div class="row g-3 mb-4">
    <?php 
      $cards = [
        'all'         => ['Total',      $counts['total'],      'background: linear-gradient(135deg,#607d8b,#455a64); color:#fff;'],
        'pending'     => ['Pending',    $counts['pending'],    'background: linear-gradient(135deg,#ffb300,#ffa000); color:#fff;'],
        'in_progress' => ['In Progress',$counts['in_progress'],'background: linear-gradient(135deg,#42a5f5,#1e88e5); color:#fff;'],
        'resolved'    => ['Resolved',   $counts['resolved'],   'background: linear-gradient(135deg,#66bb6a,#43a047); color:#fff;'],
      ];
      foreach ($cards as $key => [$label,$val,$style]):
    ?>
    <div class="col-6 col-md-3">
      <div class="card h-100 shadow-sm text-center"
           onclick="location.href='?filter=<?= $key ?>'"
           style="cursor:pointer; <?= $style ?>">
        <div class="card-body d-flex flex-column justify-content-center">
          <h6 class="card-title"><?= $label ?></h6>
          <p class="display-6 mb-0"><?= $val ?></p>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Large: Table View -->
  <div class="d-none d-md-block mb-4">
    <?php if ($grievances): ?>
    <div class="table-responsive shadow-sm">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
          <tr>
            <th>ID</th><th>Title</th><th>Description</th><th>Status</th><th>Submitted</th><th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($grievances as $g): ?>
          <tr>
            <td><?= $g['id'] ?></td>
            <td><?= htmlspecialchars($g['title']) ?></td>
            <td><?= htmlspecialchars($g['description']) ?></td>
            <td><span class="badge bg-<?= statusColor($g['status']) ?>"><?= ucfirst($g['status']) ?></span></td>
            <td><?= date('M d, Y', strtotime($g['created_at'])) ?></td>
            <td>
              <a href="chat.php?grievance_id=<?= $g['id'] ?>" class="btn btn-sm btn-gradient">Chat</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
      <div class="alert alert-info">No grievances found. Submit a new one!</div>
    <?php endif; ?>
  </div>

  <!-- Small: Card View -->
  <div class="d-md-none row g-3">
    <?php if ($grievances): foreach($grievances as $g): ?>
    <div class="col-12">
      <div class="card shadow-sm h-100" onclick="location.href='chat.php?grievance_id=<?= $g['id'] ?>'" style="cursor:pointer;">
        <div class="card-body">
          <h6 class="card-title text-truncate"><?= htmlspecialchars($g['title']) ?></h6>
          <p class="card-text text-truncate-2"><?= htmlspecialchars($g['description']) ?></p>
          <div class="d-flex justify-content-between align-items-center mt-3">
            <span class="badge bg-<?= statusColor($g['status']) ?>"><?= ucfirst($g['status']) ?></span>
            <small class="text-muted"><?= date('M d', strtotime($g['created_at'])) ?></small>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; else: ?>
      <div class="col-12">
        <div class="alert alert-info">No grievances found. Submit a new one!</div>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Floating New Grievance Button -->
<a href="submit.php" class="btn btn-gradient rounded-circle shadow-lg"
   style="position:fixed; bottom:2rem; right:2rem; width:4rem; height:4rem; display:flex; align-items:center; justify-content:center;"
   aria-label="Submit a new grievance">
  <i class="fas fa-plus"></i>
</a>

<?php include 'includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  // Chart.js for grievances over last 7 days
  const ctx = document.getElementById('grievanceChart').getContext('2d');
  const chartData = {
    labels: <?= json_encode(array_keys($grievanceCounts)) ?>,
    datasets: [{
      label: 'Grievances',
      data: <?= json_encode(array_values($grievanceCounts)) ?>,
      backgroundColor: 'rgba(66, 165, 245, 0.5)',
      borderColor: 'rgba(66, 165, 245, 1)',
      borderWidth: 1
    }]
  };
  const grievanceChart = new Chart(ctx, {
    type: 'bar',
    data: chartData,
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
</script>