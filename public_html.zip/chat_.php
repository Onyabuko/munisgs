<?php
include_once 'includes/config.php';
include_once 'includes/auth.php';
// include_once 'includes/helpers.php';
// include_once 'includes/ai_helper.php'; // Include AI helper functions
include_once 'auto_respond.php'; // Include auto-respond logic
// Check for grievance_id in the query string
if (!isset($_GET['grievance_id'])) {
    header("Location: dashboard.php");
    exit;
}

$grievance_id = $_GET['grievance_id'];

// Load grievance details
$stmt = $pdo->prepare("SELECT * FROM grievances WHERE id = ?");
$stmt->execute([$grievance_id]);
$grievance = $stmt->fetch();

if (!$grievance) {
    echo '<div class="container mt-5"><div class="alert alert-danger">Invalid grievance ID. <a href="dashboard.php" class="alert-link">Go back to Dashboard</a></div></div>';
    exit;
}

// For students: ensure they own the grievance
if ($_SESSION['user_role'] === 'student' && $grievance['user_id'] != $_SESSION['user_id']) {
    echo '<div class="container mt-5"><div class="alert alert-danger">Access Denied: You are not authorized to view this grievance. <a href="dashboard.php" class="alert-link">Go back to Dashboard</a></div></div>';
    exit;
}

// For sub-admins: ensure the grievance category matches their assigned category
if ($_SESSION['user_role'] === 'admin' && $_SESSION['admin_category'] !== 'main') {
    if ($grievance['category'] !== $_SESSION['admin_category']) {
        echo '<div class="container mt-5"><div class="alert alert-danger">Access Denied: You do not have permission to view this grievance. <a href="admin/dashboard.php" class="alert-link">Go back to Dashboard</a></div></div>';
        exit;
    }
}

// Process message submission from either role
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $message = trim($_POST['message']);
    $filePath = null;

    // Process file upload if a file is attached
    if (isset($_FILES['chat_file']) && $_FILES['chat_file']['error'] === 0) {
        // Allowed file types and max size (e.g., 5MB)
        $allowed = array(
            "jpg" => "image/jpeg",
            "jpeg" => "image/jpeg",
            "png" => "image/png",
            "gif" => "image/gif",
            "pdf" => "application/pdf"
        );
        $filename = $_FILES['chat_file']['name'];
        $filetype = mime_content_type($_FILES['chat_file']['tmp_name']);
        $filesize = $_FILES['chat_file']['size'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (!array_key_exists($ext, $allowed) || $allowed[$ext] !== $filetype) {
            $_SESSION['error'] = "Error: Please select a valid file format (jpg, jpeg, png, gif, pdf).";
        } elseif ($filesize > 5 * 1024 * 1024) { // 5MB maximum
            $_SESSION['error'] = "Error: File size is larger than the allowed limit (5MB).";
        } elseif (in_array($filetype, $allowed)) {
            if (!file_exists("uploads")) {
                mkdir("uploads", 0777, true);
            }
            if (!is_writable("uploads")) {
                $_SESSION['error'] = "Error: Upload directory is not writable.";
            }
            $newfilename = uniqid() . "_" . basename($filename);
            $destination = "uploads/" . $newfilename;
            if (move_uploaded_file($_FILES['chat_file']['tmp_name'], $destination)) {
                $filePath = $destination;
            } else {
                $_SESSION['error'] = "Error uploading file.";
            }
        } else {
            $_SESSION['error'] = "Error: There was a problem uploading your file. Please try again.";
        }
    }
    
    if (!isset($_SESSION['error'])) {
        // Determine sender ('admin' or 'student')
        $sender = $_SESSION['user_role'];
        $stmt = $pdo->prepare("INSERT INTO messages (grievance_id, sender, message, file) VALUES (?, ?, ?, ?)");
        $stmt->execute([$grievance_id, $sender, $message, $filePath]);
        
        // Update grievance status
        $new_status = ($sender === 'admin') ? 'resolved' : 'in_progress';
        $stmt = $pdo->prepare("UPDATE grievances SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $grievance_id]);
        
        $_SESSION['message'] = "Message sent.";
        header("Location: chat.php?grievance_id=" . $grievance_id);
        exit;
    }
}

if (!empty($_SESSION['error'])) {
    error_log($_SESSION['error'], 3, 'logs/errors.log');
}

// Mark unread messages as read
$stmt = $pdo->prepare("UPDATE messages SET is_read = 1 WHERE grievance_id = ? AND sender = ? AND is_read = 0");
$stmt->execute([$grievance_id, ($_SESSION['user_role'] === 'student') ? 'admin' : 'student']);

// Fetch all messages, ordered by id ASC
$stmt = $pdo->prepare("SELECT * FROM messages WHERE grievance_id = ? ORDER BY id ASC");
$stmt->execute([$grievance_id]);
$messages = $stmt->fetchAll();
?>
<?php include 'includes/header.php'; ?>
<br>
<!--container for the grievanvces-->
<div class="container py-5">
  <div class="card p-4 d-flex flex-column justify-content-between" style="min-height: 70vh;">
    <h4 class="mb-3">Grievance: <?= htmlspecialchars($grievance['title'] ?: 'Untitled Grievance') ?></h4>
    <p class="mb-3"><strong>Category:</strong> <?= htmlspecialchars($grievance['category'] ?: 'General') ?></p>
    <div class="mb-4">
      <span class="badge bg-<?php echo statusColor($grievance['status']); ?>">
        <?php echo ucfirst($grievance['status']); ?>
      </span>
    </div>
    
    <!-- Chat conversation box -->
    <div class="chat-box mb-4 flex-grow-1 overflow-auto" style="max-height: 400px; border: 1px solid #ccc; padding: 10px; border-radius: 5px;">
      <!-- Display grievance description as the first message if no messages exist -->
      <?php if (empty($messages)): ?>
        <div class="d-flex justify-content-start mb-2">
          <div class="d-inline-block p-2 rounded chat-message system-msg">
            <small class="text-muted">System:</small>
            <div class="chat-text mb-1"><?php echo nl2br(htmlspecialchars($grievance['description'])); ?></div>
            <small class="text-muted d-block"><?php echo date('M d, Y H:i', strtotime($grievance['created_at'])); ?></small>
          </div>
        </div>
      <?php endif; ?>

      <!-- Display all messages -->
      <?php foreach ($messages as $msg): ?>
        <div class="d-flex <?= $msg['sender'] === $_SESSION['user_role'] ? 'justify-content-end' : 'justify-content-start' ?> mb-2">
          <div class="d-inline-block p-2 rounded chat-message <?php echo ($msg['sender'] === 'admin') ? 'admin-msg' : 'student-msg'; ?>">
            <small class="text-muted"><?php echo ucfirst($msg['sender']); ?>:</small>
            <div class="chat-text mb-1"><?php echo nl2br(htmlspecialchars($msg['message'])); ?></div>

            <!-- Display file attachment as an icon with file name -->
            <?php if (!empty($msg['file'])): ?>
              <a href="<?php echo htmlspecialchars($msg['file']); ?>" target="_blank">
                <i class="fas fa-file-alt"></i> <?php echo basename($msg['file']); ?>
              </a>
            <?php endif; ?>
            <small class="text-muted d-block"><?php echo date('M d, Y H:i', strtotime($msg['created_at'])); ?></small>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    
    <!-- Message form with file input -->
    <form method="POST" id="responseForm" enctype="multipart/form-data">
      <div class="mb-3">
        <textarea name="message" class="form-control" placeholder="Type your message..." rows="3" required></textarea>
      </div>
      <div class="mb-3">
        <input type="file" name="chat_file" class="form-control">
      </div>
      <div class="d-flex justify-content-between align-items-center">
        <button type="submit" name="send_message" class="btn btn-gradient">Send Message</button>
        <a href="<?php echo ($_SESSION['user_role'] === 'admin') ? 'admin/dashboard.php' : 'dashboard.php'; ?>" class="btn btn-secondary">Back to Dashboard</a>
      </div>
    </form>
    
    <!-- AI Helper Section (only for admins) -->
    <?php if ($_SESSION['user_role'] === 'admin'): ?>
    <div class="d-flex justify-content-end mt-3">
      <button id="aiHelperBtn" class="btn btn-outline-primary">AI Helper</button>
    </div>
    <div id="aiResponseContainer" class="mt-3" style="display: none;">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">AI Generated Response</h5>
          <p id="aiResponseText"></p>
          <button id="insertAIResponse" class="btn btn-gradient">Insert into Chat</button>
        </div>
      </div>
    </div>
    <script>
    document.getElementById('aiHelperBtn').addEventListener('click', function() {
      let prompt = "Respond to the grievance: <?php echo addslashes($grievance['title']); ?>. " +
                   "Details: <?php echo addslashes($grievance['description']); ?>. " +
                   "Provide a professional and empathetic response to a student grievance from Muni University Uganda as the assistant Dean of Students " +
                   "The grievance is about: <?php echo addslashes($grievance['category']); ?>. " +
                   "The grievance is about: <?php echo addslashes($grievance['status']); ?>. " +
                   "The grievance is about: <?php echo addslashes($grievance['created_at']); ?>.";
      fetch("https://openrouter.ai/api/v1/chat/completions", {
          method: "POST",
          headers: {
              "Authorization": "Bearer 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", // Replace with your API key
              "HTTP-Referer": "https://munisgs.online/", // Replace with your site URL
              "X-Title": "Student Grievance System", // Replace with your site name
              "Content-Type": "application/json"
          },
          body: JSON.stringify({
              "model": "deepseek/deepseek-r1-distill-llama-70b:free",
              "messages": [
                  { "role": "user", "content": prompt }
              ]
          })
      })
      .then(response => response.json())
      .then(data => {
          if (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) {
              document.getElementById('aiResponseText').innerText = data.choices[0].message.content;
          } else {
              document.getElementById('aiResponseText').innerText = "No response from AI.";
          }
          document.getElementById('aiResponseContainer').style.display = 'block';
      })
      .catch(error => {
          console.error('Error:', error);
          document.getElementById('aiResponseText').innerText = "Error: " + error;
          document.getElementById('aiResponseContainer').style.display = 'block';
      });
    });
    
    document.getElementById('insertAIResponse').addEventListener('click', function() {
      let aiText = document.getElementById('aiResponseText').innerText;
      let messageInput = document.querySelector('textarea[name="message"]');
      if(messageInput) {
          messageInput.value = aiText;
      }
    });
    </script>
    <?php endif; ?>
    
  </div>
</div>

<style>
.chat-box {
    overflow-y: auto;
    word-wrap: break-word;
}
</style>
