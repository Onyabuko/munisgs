<?php
// auto_respond.php

include 'includes/config.php';
include 'includes/helpers.php';
include 'ai_helper.php';  // Contains the getAIResponse() function
include 'includes/auth.php'; // Ensure the user is authenticated
include 'chat.php';

// Fetch grievances eligible for auto-response
// This script will run every 15 minutes to check for grievances that need auto-responses.
// It will check the current time and determine if it's within working hours or peak hours.
// Working hours are defined as 7:00 AM to 10:00 PM (22:00).
// Peak hours are defined as 10:00 PM to 6:00 AM (22:00 to 6:00).



// Determine the current hour in 24-hour format (0-23)
$currentHour = (int) date('G');

// Set time limit based on working hours vs. peak hours
// Working hours: 7:00 <= hour < 22:00  -> 15-minute delay
// Peak hours: hour >= 23 OR hour < 6  -> Immediate response (0 delay)
// For transitional hours (6-7 and 22-23), we'll treat them as working hours.
if ($currentHour >= 7 && $currentHour < 22) {
    $timeLimit = 15 * 60; // 15 minutes in seconds
} else {
    $timeLimit = 0; // Immediate response during peak hours
}

// Calculate the threshold time (grievances older than this are eligible for auto-response)
$thresholdTime = date('Y-m-d H:i:s', time() - $timeLimit);

// Build the query condition based on the time limit
if ($timeLimit > 0) {
    // Working hours: Only select grievances older than the threshold
    $query = "SELECT g.id, g.title, g.description, g.created_at 
              FROM grievances g
              WHERE (g.status = 'pending' OR g.status = 'in_progress')
                AND g.created_at <= :threshold
                AND NOT EXISTS (
                    SELECT 1 FROM messages m 
                    WHERE m.grievance_id = g.id AND m.sender = 'admin'
                )
                AND g.auto_responded = 0";
} else {
    // Peak hours: Respond immediately to grievances that haven't received an admin response.
    $query = "SELECT g.id, g.title, g.description, g.created_at 
              FROM grievances g
              WHERE (g.status = 'pending' OR g.status = 'in_progress')
                AND NOT EXISTS (
                    SELECT 1 FROM messages m 
                    WHERE m.grievance_id = g.id AND m.sender = 'admin'
                )
                AND g.auto_responded = 0";
}

$stmt = $pdo->prepare($query);
if ($timeLimit > 0) {
    $stmt->bindParam(':threshold', $thresholdTime);
}
$stmt->execute();
$grievancesToRespond = $stmt->fetchAll();

// Loop through eligible grievances and auto-respond.
foreach ($grievancesToRespond as $grievance) {
    // Construct a prompt for the AI helper.
    $prompt = "A student submitted the following grievance: \"" 
              . $grievance['title'] . "\". Details: " 
              . $grievance['description'] 
              . ". Please provide an empathetic and professional response that acknowledges the issue and advises that an admin will follow up shortly.";
    
    // Call the AI helper to generate a reply.
    $aiResponse = getAIResponse($prompt);
    
    // Insert the AI-generated response as a message from the admin.
    $insertStmt = $pdo->prepare("INSERT INTO messages (grievance_id, sender, message, is_read) VALUES (?, 'admin', ?, 1)");
    $insertStmt->execute([$grievance['id'], $aiResponse]);
    
    // Update the grievance status to 'resolved' (or another appropriate status)
    $updateStmt = $pdo->prepare("UPDATE grievances SET status = 'resolved', auto_responded = 1 WHERE id = ?");
    $updateStmt->execute([$grievance['id']]);
    
    // (Optional) Log the auto-response for auditing purposes.
    $logStmt = $pdo->prepare("INSERT INTO auto_responses (grievance_id, response) VALUES (?, ?)");
    $logStmt->execute([$grievance['id'], $aiResponse]);
    
    echo "Auto-response sent for grievance ID: " . $grievance['id'] . "<br>";
    // Optionally, you can send an email notification to the student about the auto-response.
    // sendEmailNotification($grievance['student_email'], $aiResponse); // Implement this function as needed.
    // Note: Ensure that the 'auto_responded' column exists in the grievances table to track auto-responses.

}
?>
