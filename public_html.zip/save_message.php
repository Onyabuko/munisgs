<?php
include 'includes/config.php';
include 'includes/auth.php'; // Ensure the user is logged in

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $user_id = $_SESSION['user_id'];
    $role = $data['role'];
    $message = $data['message'];

    // Save the message to the database
    $stmt = $pdo->prepare("INSERT INTO chat_messages (user_id, role, message) VALUES (?, ?, ?)");
    if ($stmt->execute([$user_id, $role, $message])) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to save message']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}