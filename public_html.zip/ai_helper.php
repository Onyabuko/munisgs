<?php
// ai_helper.php
include 'includes/config.php';

/**
 * getAIResponse - Calls the AI API (e.g., OpenAI's ChatGPT) to generate a reply.
 *
 * @param string $prompt The prompt text for the AI.
 * @return string The AI-generated response or an error message.
 */
function getAIResponse($prompt) {
    //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
    // Replace with your actual API key from OpenAI
    //$apiKey = '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';
    $apiKey = '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';
    
    $postData = [
        'model' => 'deepseek/deepseek-r1:free',
        'messages' => [
            ['role' => 'system', 'content' => 'You are an expert admin assistant that helps respond to student grievances in a compassionate and professional manner.'],
            ['role' => 'user', 'content' => $prompt]
        ],
        'temperature' => 0.7,
    ];
    
    $ch = curl_init('https://openrouter.ai/api/v1/chat/completions');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey,
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
    
    // Optional: For testing on some systems, you may temporarily disable SSL verification
    // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
        curl_close($ch);
        return "cURL Error: " . $error_msg;
    }
    curl_close($ch);
    
    $response = json_decode($result, true);
    
    // Check if API returned an error
    if (isset($response['error'])) {
        return "API Error: " . $response['error']['message'];
    }
    
    if (isset($response['choices'][0]['message']['content'])) {
        return trim($response['choices'][0]['message']['content']);
    }
    return "No response from AI.";
}

// Check if the current time is within the emergency window (e.g., 00:00 to 04:00)
$currentHour = (int) date('H');
if ($currentHour >= 0 && $currentHour < 4) {
    // Automatically generate an emergency auto-response for new grievances
    $emergencyPrompt = "A student has submitted a grievance during emergency hours (late at night). Provide an urgent, empathetic reply advising the student that their issue is being escalated and that an admin will follow up as soon as possible.";
    $autoResponse = getAIResponse($emergencyPrompt);
    // For testing, output the response; in production you might log or store it
    echo $autoResponse;
} else {
    // For non-emergency use: if a prompt is passed via POST, generate a response
    if (isset($_POST['prompt'])) {
         $prompt = trim($_POST['prompt']);
         $aiResponse = getAIResponse($prompt);
         echo $aiResponse;
    } else {
         echo "No prompt provided.";
    }
}
?>
