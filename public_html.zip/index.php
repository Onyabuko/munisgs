<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MuniSGS - Muni University Student Grievance System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: #1e3a8a;
            padding: 10px 0;
        }
        .navbar-brand img {
            height: 40px;
        }
        .navbar-nav .nav-link {
            color: white !important;
            margin-left: 15px;
            font-weight: 500;
        }
        .navbar-nav .nav-link:hover {
            color: #3b82f6 !important;
        }
        .hero-section {
            background: linear-gradient(135deg, #1e3a8a, #3b82f6);
            color: white;
            padding: 60px 0;
            text-align: center;
        }
        .hero-section h1 {
            font-size: 2.5rem;
            font-weight: bold;
        }
        .section {
            padding: 40px 0;
        }
        .section h2 {
            font-size: 1.8rem;
            margin-bottom: 20px;
            color: #1e3a8a;
        }
        .card {
            border: none;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .procedure-step {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .procedure-step .icon {
            font-size: 2rem;
            color: #3b82f6;
            margin-right: 15px;
        }
        .footer {
            background-color: #1e3a8a;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        .btn-primary {
            background-color: #3b82f6;
            border-color: #3b82f6;
        }
        .btn-primary:hover {
            background-color: #1e3a8a;
            border-color: #1e3a8a;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="/">
                <img src="./assets/images/logo.jpg" alt="Muni University Logo">
                MuniSGS
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Create Account</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section" style="margin-top: 60px;">
        <div class="container">
            <h1>Welcome to MuniSGS</h1>
            <p class="lead">Muni University Student Grievance System - Your Voice Matters!</p>
            <a href="login.php" class="btn btn-light btn-lg mt-3">Get Started</a>
        </div>
    </section>

    <!-- About Grievances Section -->
    <section class="section">
        <div class="container">
            <h2>What Are Grievances?</h2>
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <p>A grievance is any concern, complaint, or issue you may have related to your academic, social, or administrative experiences at Muni University. The MuniSGS is designed to provide a safe, confidential, and efficient platform for students to report grievances and seek resolution.</p>
                    <p>Whether it’s an issue with facilities, academic processes, or interpersonal conflicts, we’re here to listen and help. Our goal is to ensure a fair and supportive environment for all students.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Words of Encouragement Section -->
    <section class="section" style="background-color: #e9ecef;">
        <div class="container">
            <h2>Words of Encouragement</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card p-3 text-center">
                        <i class="fas fa-heart fa-2x mb-3 text-primary"></i>
                        <h5>Speak Up</h5>
                        <p>Your voice is powerful. Don’t hesitate to share your concerns—we’re here to support you.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3 text-center">
                        <i class="fas fa-shield-alt fa-2x mb-3 text-primary"></i>
                        <h5>Feel Safe</h5>
                        <p>Your privacy is our priority. All submissions are handled with confidentiality.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-3 text-center">
                        <i class="fas fa-handshake fa-2x mb-3 text-primary"></i>
                        <h5>Find Solutions</h5>
                        <p>We’re committed to resolving your issues fairly and promptly.</p>
                    </div>
                </div>
            </div>
            <div class="text-center mt-4">
                <p>For additional support, visit the <b>Office if the Dean of Studens</b> to access resources for a safer campus environment.</p>
            </div>
        </div>
    </section>

    <!-- Procedure for Sending Grievances Section -->
    <section class="section">
        <div class="container">
            <h2>How to Submit a Grievance</h2>
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="procedure-step">
                        <i class="fas fa-user-circle icon"></i>
                        <div>
                            <h5>Step 1: Log In</h5>
                            <p>Access the MuniSGS portal using your student credentials.</p>
                        </div>
                    </div>
                    <div class="procedure-step">
                        <i class="fas fa-edit icon"></i>
                        <div>
                            <h5>Step 2: Fill Out the Form</h5>
                            <p>Provide details about your grievance, including the category, description, and any supporting documents.</p>
                        </div>
                    </div>
                    <div class="procedure-step">
                        <i class="fas fa-paper-plane icon"></i>
                        <div>
                            <h5>Step 3: Submit</h5>
                            <p>Send your grievance for review. You’ll receive a confirmation and can track its progress.</p>
                        </div>
                    </div>
                    <div class="procedure-step">
                        <i class="fas fa-comments icon"></i>
                        <div>
                            <h5>Step 4: Stay Updated</h5>
                            <p>Communicate with administrators via the portal and receive updates on your grievance’s status.</p>
                        </div>
                    </div>
                    <div class="text-center mt-4">
                        <a href="./login.php" class="btn btn-primary btn-lg">Submit a Grievance Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>© 2025 Muni University. All rights reserved.</p>
            <p>Contact us: <a href="mailto:support@muni.ac.ug" style="color: #ffffff;">support@muni.ac.ug</a></p>
        </div>
    </footer>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</body>
</html>