<?php
include 'includes/config.php';
include 'includes/auth.php'; // Ensure the user is logged in

// Fetch categories from database
$categories = [];
$stmt = $pdo->prepare("SELECT id, name FROM categories ORDER BY name");
$stmt->execute();
$categories = $stmt->fetchAll();

if (isset($_POST['submit_grievance'])) {
    $description = trim($_POST['description']);
    $category_id = intval($_POST['category_id']);
    $file_path = null;
    $voicenote_path = null;

    // Get category name from ID
    $category_name = '';
    foreach ($categories as $cat) {
        if ($cat['id'] == $category_id) {
            $category_name = $cat['name'];
            break;
        }
    }

    if (empty($category_name)) {
        $_SESSION['error'] = "Invalid category selected.";
        header("Location: submit.php");
        exit;
    }

    // Handle file upload
    if (!empty($_FILES['attachment']['name'])) {
        $file_name = time() . '_' . basename($_FILES['attachment']['name']);
        $file_path = 'uploads/' . $file_name;
        $allowed_types = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (!in_array($file_ext, $allowed_types)) {
            $_SESSION['error'] = "Invalid file type. Allowed types: jpg, jpeg, png, pdf, doc, docx.";
            header("Location: submit.php");
            exit;
        }

        if ($_FILES['attachment']['size'] > 5000000) { // 5MB limit
            $_SESSION['error'] = "File size exceeds 5MB limit.";
            header("Location: submit.php");
            exit;
        }

        if (!move_uploaded_file($_FILES['attachment']['tmp_name'], $file_path)) {
            $_SESSION['error'] = "Failed to upload file.";
            header("Location: submit.php");
            exit;
        }
    }

    // Handle voicenote upload
    if (!empty($_FILES['voicenote']['name'])) {
        $voicenote_name = time() . '_voicenote_' . basename($_FILES['voicenote']['name']);
        $voicenote_path = 'uploads/' . $voicenote_name;
        $allowed_audio_types = ['mp3', 'wav', 'ogg'];

        $voicenote_ext = strtolower(pathinfo($voicenote_name, PATHINFO_EXTENSION));
        if (!in_array($voicenote_ext, $allowed_audio_types)) {
            $_SESSION['error'] = "Invalid voicenote format. Allowed types: mp3, wav, ogg.";
            header("Location: submit.php");
            exit;
        }

        if ($_FILES['voicenote']['size'] > 10000000) { // 10MB limit
            $_SESSION['error'] = "Voicenote size exceeds 10MB limit.";
            header("Location: submit.php");
            exit;
        }

        if (!move_uploaded_file($_FILES['voicenote']['tmp_name'], $voicenote_path)) {
            $_SESSION['error'] = "Failed to upload voicenote.";
            header("Location: submit.php");
            exit;
        }
    }

    // Insert grievance into database
$stmt = $pdo->prepare("INSERT INTO grievances (user_id, description, category, file, voicenote, auto_responded) VALUES (?, ?, ?, ?, ?, 0)");
if ($stmt->execute([$_SESSION['user_id'], $description, $category_name, $file_path, $voicenote_path])) {
    $_SESSION['message'] = "Grievance submitted successfully!";
    header("Location: dashboard.php");
    exit;
} else {
    $_SESSION['error'] = "Failed to submit grievance.";
    header("Location: submit.php");
    exit;
}
}
?>

<?php include 'includes/header.php'; ?>
<br><br>
<div class="container min-vh-100 d-flex align-items-center">
  <div class="card mx-auto p-4" style="width: 100%; max-width: 500px;">
    <h2 class="text-center mb-4">Submit Grievance</h2>
    <?php if (isset($_SESSION['error'])): ?>
      <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <form id="submitForm" action="submit.php" method="POST" enctype="multipart/form-data">
      
      <!-- Category Dropdown from database -->
      <div class="mb-3">
        <select name="category_id" class="form-select" required>
          <option value="">Select Category</option>
          <?php foreach ($categories as $category): ?>
            <option value="<?php echo $category['id']; ?>">
              <?php echo htmlspecialchars($category['name']); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Description input -->
      <div class="mb-3">
        <textarea name="description" class="form-control" placeholder="Describe your grievance..." rows="8" required></textarea>
      </div>

      <!-- File attachment -->
      <div class="mb-3 d-flex align-items-center gap-2">
        <label for="attachment" class="form-label mb-0 small">Attach File</label>
        <input type="file" name="attachment" id="attachment" class="form-control form-control-sm" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
        <button type="button" id="clearAttachment" class="btn btn-sm btn-outline-danger d-none" title="Clear File">
          <i class="bi bi-trash"></i>
        </button>
      </div>

      <!-- Voicenote recording -->
      <div class="mb-3 d-flex align-items-center gap-2">
        <label class="form-label mb-0 small">Record Voicenote</label>
        <button type="button" id="startRecording" class="btn btn-sm btn-outline-primary" title="Start Recording">
          <i class="bi bi-mic-fill"></i>
        </button>
        <button type="button" id="stopRecording" class="btn btn-sm btn-outline-danger" title="Stop Recording" disabled>
          <i class="bi bi-stop-fill"></i>
        </button>
        <button type="button" id="clearVoicenote" class="btn btn-sm btn-outline-danger dureusement-none" title="Clear Voicenote">
          <i class="bi bi-trash"></i>
        </button>
        <input type="file" name="voicenote" id="voicenote" class="d-none" accept=".mp3,.wav,.ogg">
        <audio id="audioPlayback" controls class="mt-2 w-100 d-none"></audio>
      </div>

      <button type="submit" name="submit_grievance" class="btn-gradient w-100">Submit</button>
    </form>
  </div>
</div>

<script>
let mediaRecorder;
let audioChunks = [];
const startButton = document.getElementById('startRecording');
const stopButton = document.getElementById('stopRecording');
const clearVoicenoteButton = document.getElementById('clearVoicenote');
const audioPlayback = document.getElementById('audioPlayback');
const voicenoteInput = document.getElementById('voicenote');
const attachmentInput = document.getElementById('attachment');
const clearAttachmentButton = document.getElementById('clearAttachment');

startButton.addEventListener('click', async () => {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        
        mediaRecorder.ondataavailable = (event) => {
            audioChunks.push(event.data);
        };

        mediaRecorder.onstop = () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
            const audioUrl = URL.createObjectURL(audioBlob);
            audioPlayback.src = audioUrl;
            audioPlayback.classList.remove('d-none');
            clearVoicenoteButton.classList.remove('d-none');

            // Convert Blob to File for form submission
            const audioFile = new File([audioBlob], `voicenote_${Date.now()}.wav`, { type: 'audio/wav' });
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(audioFile);
            voicenoteInput.files = dataTransfer.files;

            audioChunks = [];
        };

        mediaRecorder.start();
        startButton.disabled = true;
        stopButton.disabled = false;
    } catch (err) {
        alert('Microphone access denied or not available.');
        console.error(err);
    }
});

stopButton.addEventListener('click', () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        startButton.disabled = false;
        stopButton.disabled = true;
    }
});

clearVoicenoteButton.addEventListener('click', () => {
    audioPlayback.classList.add('d-none');
    audioPlayback.src = '';
    voicenoteInput.value = '';
    clearVoicenoteButton.classList.add('d-none');
    startButton.disabled = false;
});

attachmentInput.addEventListener('change', () => {
    if (attachmentInput.files.length > 0) {
        clearAttachmentButton.classList.remove('d-none');
    } else {
        clearAttachmentButton.classList.add('d-none');
    }
});

clearAttachmentButton.addEventListener('click', () => {
    attachmentInput.value = '';
    clearAttachmentButton.classList.add('d-none');
});
</script>

<!-- Include Bootstrap Icons for the button icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<?php include 'includes/footer.php'; ?>