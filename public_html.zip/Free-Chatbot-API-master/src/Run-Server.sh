#!/bin/bash

# uvicorn main:app --reload --port 8000
python main.py
