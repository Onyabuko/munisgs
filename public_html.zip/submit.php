<?php
include 'includes/config.php';
include 'includes/auth.php'; // Ensure the user is logged in

// Ensure Uploads directory exists
$upload_dir = 'Uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
    chmod($upload_dir, 0777);
}

// Fetch categories from database
$categories = [];
$stmt = $pdo->prepare("SELECT id, name FROM categories ORDER BY name");
$stmt->execute();
$categories = $stmt->fetchAll();

if (isset($_POST['submit_grievance'])) {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $category_id = intval($_POST['category_id']);
    $file_path = null;
    $voicenote_path = null;

    // Get category name from ID
    $category_name = '';
    foreach ($categories as $cat) {
        if ($cat['id'] == $category_id) {
            $category_name = $cat['name'];
            break;
        }
    }

    if (empty($category_name)) {
        $_SESSION['error'] = "Invalid category selected.";
        header("Location: submit.php");
        exit;
    }

    if (empty($title)) {
        $_SESSION['error'] = "Title is required.";
        header("Location: submit.php");
        exit;
    }

    // Handle file upload
    if (!empty($_FILES['attachment']['name']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        $file_name = time() . '_' . preg_replace("/[^a-zA-Z0-9._-]/", "_", basename($_FILES['attachment']['name']));
        $file_path = $upload_dir . $file_name;
        $allowed_types = [
            'jpg', 'jpeg', 'png', 'gif', 'bmp', // Images
            'pdf', 'doc', 'docx', 'txt', 'rtf', 'odt', // Documents
            'xlsx', 'xls', 'ppt', 'pptx', // Spreadsheets and presentations
            'zip', 'rar', // Archives
            'mp3', 'wav', 'ogg', 'm4a' // Audio (for flexibility)
        ];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (!in_array($file_ext, $allowed_types)) {
            $_SESSION['error'] = "Invalid file type. Allowed types: " . implode(", ", $allowed_types) . ".";
            header("Location: submit.php");
            exit;
        }

        if ($_FILES['attachment']['size'] > 10000000) { // 10MB limit
            $_SESSION['error'] = "File size exceeds 10MB limit.";
            header("Location: submit.php");
            exit;
        }

        // Ensure the upload directory is writable
        if (!is_writable($upload_dir)) {
            $_SESSION['error'] = "Upload directory is not writable. Contact the administrator.";
            header("Location: submit.php");
            exit;
        }

        if (!move_uploaded_file($_FILES['attachment']['tmp_name'], $file_path)) {
            $_SESSION['error'] = "Failed to upload file. Possible issues: disk full, permissions, or server configuration.";
            header("Location: submit.php");
            exit;
        }
    } elseif ($_FILES['attachment']['error'] !== UPLOAD_ERR_NO_FILE) {
        $_SESSION['error'] = "File upload error: " . $_FILES['attachment']['error'];
        header("Location: submit.php");
        exit;
    }

    // Handle voicenote upload
    if (!empty($_FILES['voicenote']['name']) && $_FILES['voicenote']['error'] === UPLOAD_ERR_OK) {
        $voicenote_name = time() . '_voicenote_' . preg_replace("/[^a-zA-Z0-9._-]/", "_", basename($_FILES['voicenote']['name']));
        $voicenote_path = $upload_dir . $voicenote_name;
        $allowed_audio_types = ['mp3', 'wav', 'ogg', 'm4a'];

        $voicenote_ext = strtolower(pathinfo($voicenote_name, PATHINFO_EXTENSION));
        if (!in_array($voicenote_ext, $allowed_audio_types)) {
            $_SESSION['error'] = "Invalid voicenote format. Allowed types: mp3, wav, ogg, m4a.";
            header("Location: submit.php");
            exit;
        }

        if ($_FILES['voicenote']['size'] > 10000000) { // 10MB limit
            $_SESSION['error'] = "Voicenote size exceeds 10MB limit.";
            header("Location: submit.php");
            exit;
        }

        if (!is_writable($upload_dir)) {
            $_SESSION['error'] = "Upload directory is not writable. Contact the administrator.";
            header("Location: submit.php");
            exit;
        }

        if (!move_uploaded_file($_FILES['voicenote']['tmp_name'], $voicenote_path)) {
            $_SESSION['error'] = "Failed to upload voicenote. Possible issues: disk full, permissions, or server configuration.";
            header("Location: submit.php");
            exit;
        }
    } elseif ($_FILES['voicenote']['error'] !== UPLOAD_ERR_NO_FILE) {
        $_SESSION['error'] = "Voicenote upload error: " . $_FILES['voicenote']['error'];
        header("Location: submit.php");
        exit;
    }

    // Insert grievance into database
    try {
        $stmt = $pdo->prepare("INSERT INTO grievances (user_id, title, description, file, voicenote, category, status, auto_responded) VALUES (?, ?, ?, ?, ?, ?, 'pending', 0)");
        $stmt->execute([$_SESSION['user_id'], $title, $description, $file_path, $voicenote_path, $category_name]);
        $_SESSION['message'] = "Grievance submitted successfully!";
        header("Location: dashboard.php");
        exit;
    } catch (Exception $e) {
        $_SESSION['error'] = "Failed to submit grievance: " . $e->getMessage();
        header("Location: submit.php");
        exit;
    }
}
?>

<?php include 'includes/header.php'; ?>

<style>
/* Custom styles for chat-like interface */
body {
    background-color: #f1f3f5;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
}

.chat-container {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1rem;
}

.chat-card {
    background: #ffffff;
    border-radius: 1rem;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 600px;
    overflow: hidden;
}

.chat-header {
    background: #007bff;
    color: white;
    padding: 1rem;
    text-align: center;
    border-top-left-radius: 1rem;
    border-top-right-radius: 1rem;
}

.chat-body {
    padding: 1.5rem;
}

.form-select, .form-control {
    border-radius: 0.5rem;
    border: 1px solid #ced4da;
    padding: 0.75rem;
    transition: border-color 0.2s;
}

.form-select:focus, .form-control:focus {
    border-color: #007bff;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

.textarea-chat {
    border-radius: 1rem;
    resize: vertical;
    padding: 1rem;
    background: #f8f9fa;
}

.btn-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    border: none;
    background: #e9ecef;
    transition: background 0.2s, transform 0.1s;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.btn-icon:hover {
    background: #dee2e6;
    transform: translateY(-2px);
}

.btn-icon:disabled {
    background: #ced4da;
    cursor: not-allowed;
    opacity: 0.7;
}

.btn-icon-clear {
    border: 1px solid #dc3545;
    background: transparent;
    color: #dc3545;
}

.btn-icon-clear:hover {
    background: #dc3545;
    color: white;
}

.btn-submit {
    background: linear-gradient(90deg, #007bff, #00d4ff);
    color: white;
    border: none;
    border-radius: 0.5rem;
    padding: 0.75rem;
    font-weight: 500;
    transition: background 0.2s, transform 0.1s;
    box-shadow: 0 2px 8px rgba(0, 123, 255, 0.3);
}

.btn-submit:hover {
    background: linear-gradient(90deg, #0056b3, #00aaff);
    transform: translateY(-2px);
}

.btn-submit:active {
    transform: scale(0.98);
}

.audio-player {
    width: 100%;
    margin-top: 0.5rem;
    border-radius: 0.5rem;
}

.input-group-chat {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    flex-wrap: wrap;
}

.alert {
    border-radius: 0.5rem;
    margin-bottom: 1rem;
}

/* Accessibility */
:focus-visible {
    outline: 2px solid #007bff;
    outline-offset: 2px;
}

@media (max-width: 576px) {
    .chat-card {
        margin: 0.5rem;
    }
    .btn-icon {
        width: 36px;
        height: 36px;
    }
    .chat-body {
        padding: 1rem;
    }
}
</style>

<div class="chat-container">
    <div class="chat-card">
        <div class="chat-header">
            <h2 class="mb-0">Submit Grievance</h2>
        </div>
        <div class="chat-body">
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
            <form id="submitForm" action="submit.php" method="POST" enctype="multipart/form-data">
                <!-- Title Input -->
                <div class="mb-3">
                    <input type="text" name="title" class="form-control" placeholder="Grievance Title" required aria-label="Grievance title">
                </div>

                <!-- Category Dropdown -->
                <div class="mb-3">
                    <select name="category_id" class="form-select" required aria-label="Select grievance category">
                        <option value="">Select Category</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>">
                                <?php echo htmlspecialchars($category['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Description Input -->
                <div class="mb-3">
                    <textarea name="description" class="form-control textarea-chat" placeholder="Type your grievance..." rows="6" required aria-label="Grievance description"></textarea>
                </div>

                <!-- Attachment and Voicenote Controls -->
                <div class="input-group-chat mb-3">
                    <!-- Attachment -->
                    <label for="attachment" class="btn-icon" title="Attach file" aria-label="Attach file">
                        <i class="bi bi-paperclip"></i>
                    </label>
                    <input type="file" name="attachment" id="attachment" class="d-none" accept=".jpg,.jpeg,.png,.gif,.bmp,.pdf,.doc,.docx,.txt,.rtf,.odt,.xlsx,.xls,.ppt,.pptx,.zip,.rar,.mp3,.wav,.ogg,.m4a" aria-label="File attachment">
                    <button type="button" id="clearAttachment" class="btn-icon btn-icon-clear d-none" title="Clear attachment" aria-label="Clear attachment">
                        <i class="bi bi-trash"></i>
                    </button>

                    <!-- Voicenote -->
                    <button type="button" id="startRecording" class="btn-icon" title="Start recording" aria-label="Start recording voicenote">
                        <i class="bi bi-mic-fill"></i>
                    </button>
                    <button type="button" id="stopRecording" class="btn-icon" title="Stop recording" aria-label="Stop recording voicenote" disabled>
                        <i class="bi bi-stop-fill"></i>
                    </button>
                    <button type="button" id="clearVoicenote" class="btn-icon btn-icon-clear d-none" title="Clear voicenote" aria-label="Clear voicenote">
                        <i class="bi bi-trash"></i>
                    </button>
                    <input type="file" name="voicenote" id="voicenote" class="d-none" accept=".mp3,.wav,.ogg,.m4a" aria-label="Voicenote file">
                </div>

                <!-- Audio Playback -->
                <audio id="audioPlayback" controls class="audio-player d-none" aria-label="Voicenote playback"></audio>

                <!-- Submit Button -->
                <button type="submit" name="submit_grievance" class="btn-submit w-100">Send Grievance</button>
            </form>
        </div>
    </div>
</div>

<script>
// Existing JavaScript unchanged
let mediaRecorder;
let audioChunks = [];
const startButton = document.getElementById('startRecording');
const stopButton = document.getElementById('stopRecording');
const clearVoicenoteButton = document.getElementById('clearVoicenote');
const audioPlayback = document.getElementById('audioPlayback');
const voicenoteInput = document.getElementById('voicenote');
const attachmentInput = document.getElementById('attachment');
const clearAttachmentButton = document.getElementById('clearAttachment');

startButton.addEventListener('click', async () => {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        
        mediaRecorder.ondataavailable = (event) => {
            audioChunks.push(event.data);
        };

        mediaRecorder.onstop = () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
            const audioUrl = URL.createObjectURL(audioBlob);
            audioPlayback.src = audioUrl;
            audioPlayback.classList.remove('d-none');
            clearVoicenoteButton.classList.remove('d-none');

            // Convert Blob to File for form submission
            const audioFile = new File([audioBlob], `voicenote_${Date.now()}.wav`, { type: 'audio/wav' });
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(audioFile);
            voicenoteInput.files = dataTransfer.files;

            audioChunks = [];
        };

        mediaRecorder.start();
        startButton.disabled = true;
        stopButton.disabled = false;
    } catch (err) {
        alert('Microphone access denied or not available.');
        console.error(err);
    }
});

stopButton.addEventListener('click', () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        startButton.disabled = false;
        stopButton.disabled = true;
    }
});

clearVoicenoteButton.addEventListener('click', () => {
    audioPlayback.classList.add('d-none');
    audioPlayback.src = '';
    voicenoteInput.value = '';
    clearVoicenoteButton.classList.add('d-none');
    startButton.disabled = false;
});

attachmentInput.addEventListener('change', () => {
    if (attachmentInput.files.length > 0) {
        clearAttachmentButton.classList.remove('d-none');
    } else {
        clearAttachmentButton.classList.add('d-none');
    }
});

clearAttachmentButton.addEventListener('click', () => {
    attachmentInput.value = '';
    clearAttachmentButton.classList.add('d-none');
});
</script>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<?php include 'includes/footer.php'; ?>