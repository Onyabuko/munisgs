<?php
session_start(); // Start session at the 
require_once('includes/config.php');

//Lastupdate 15/04/2025 15:03

// // Database configuration
// $host = 'localhost';
// $dbname = 'grievance_system';
// $username = 'root'; // replace with your database username
// $password = ''; // replace with your database password

// // Create connection
// $conn = new mysqli($host, $username, $password, $dbname);

// // Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

// Set up PHPMailer
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Function to send OTP via email
function sendOTPByEmail($email, $otp) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'onyabukoisaac@gmail.com'; // Replace with your email
        $mail->Password = 'mwixhsfetdmfdnhu'; // Replace with your email password
        $mail->Port = 587; // TLS
        
        $mail->setFrom('onyabukoisaac@gmail.com', 'Admin');
        $mail->addAddress($email);
        
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Code';
        $mail->Body = "<h3>Your OTP Code is:</h3><p>$otp</p>";
        $mail->AltBody = "Your OTP code is: $otp";
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        return false;
    }
}

// Function to validate student email prefix
function isValidStudentEmail($email) {
    // Extract the prefix (first 3 characters before the @ symbol)
    $prefix = substr($email, 0, 3);
    // Check if the prefix starts with 220, 230, 240, etc.
    return in_array($prefix, ['220', '230', '240']);
}

// Handle OTP request via AJAX
if (isset($_POST['action']) && $_POST['action'] == 'request_otp') {
    $email = $_POST['email'];
    if (filter_var($email, FILTER_VALIDATE_EMAIL) && substr($email, -11) === '@muni.ac.ug') {
        // Check if the email prefix is valid
        if (!isValidStudentEmail($email)) {
            echo json_encode(['status' => 'error', 'message' => 'Only students with valid email prefixes (220.., 230.., 240.., etc.) can register.']);
            exit();
        }

        $otp = rand(100000, 999999);
        $_SESSION['otp'] = ['code' => $otp, 'expires' => time() + 300]; // Expires in 5 minutes
        
        if (sendOTPByEmail($email, $otp)) {
            echo json_encode(['status' => 'success', 'message' => 'OTP sent to your email!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to send OTP. Please try again.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid Muni email address.']);
    }
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['verify_otp'])) {
    $input_otp = $_POST['otp'];
    // Validate OTP expiration
    if (time() > $_SESSION['otp']['expires']) {
        unset($_SESSION['otp']);
        echo "<script>alert('OTP expired. Please request a new one.');</script>";
        exit();
    }
    if ($input_otp == $_SESSION['otp']['code']) {
        $email = $_POST['email'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];

        // Validate email prefix again during form submission
        if (!isValidStudentEmail($email)) {
            echo "<script>alert('Only students with valid email prefixes (220.., 230.., 240.., etc.) can register.');</script>";
            echo "<script>window.location.href = 'register.php';</script>";
            exit();
        }

        if ($password !== $confirm_password) {
            echo "<script>alert('Passwords do not match!');</script>";
            echo "<script>window.location.href = 'register.php';</script>";
            exit();
        }

        if (!preg_match('/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/', $password)) {
            echo "<script>alert('Password must be at least 8 characters long and include letters and numbers.');</script>";
            exit();
        }

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");

        // Check if the prepare() method succeeded
        if ($stmt === false) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("sss", $username, $email, $hashed_password);

        if ($stmt->execute()) {
            echo "<script>
                    alert('Registration successful! Please login to continue');
                    window.location.href = 'index.php';
                  </script>";
        } else {
            // Check for duplicate entry error (MySQL error code 1062)
            if ($stmt->errno == 1062) {
                echo "<script>alert('This email is already registered. Please use a different email or log in.');</script>";
            } else {
                echo "<script>alert('Error: " . addslashes($stmt->error) . "');</script>";
            }
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "<script>alert('Invalid OTP!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Registration</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Your CSS styles here */
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --light: #f8f9fa;
            --dark: #212529;
            --success: #4cc9f0;
            --gradient: linear-gradient(135deg, var(--primary), var(--secondary));
        }

        body {
            background: #f0f2f5;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 1rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.18);
            transition: transform 0.3s ease;
            width: 100%;
            max-width: 500px;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .btn-gradient {
            background: var(--gradient);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 50px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: 0.3s;
        }

        .btn-gradient::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.3), transparent);
            transform: rotate(45deg);
            transition: 0.5s;
        }

        .btn-gradient:hover::after {
            animation: shine 1.5s;
        }

        @keyframes shine {
            0% { left: -50%; }
            100% { left: 150%; }
        }

        .form-control {
            border-radius: 0.5rem;
            padding: 10px;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .copyright_section {
            text-align: center;
            margin-top: auto;
            padding: 20px;
            color: #6c757d;
        }
    </style>
</head>
<body>
<?php include 'includes/header.php'; ?>
<br><br><br>
    <div class="container">
        <div class="card mx-auto p-4">
            <h2 class="text-center mb-4">Create Account</h2>
            <form id="registerForm" action="" method="POST">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter your Muni email" required>
                </div>
                <div class="form-group text-center">
                    <button type="button" id="requestOtpButton" class="btn btn-gradient" style="padding:5px; width:70%;">Request OTP</button>
                </div>
                <div id="otp-message" style="display: none;" class="alert alert-success">
                    OTP sent successfully!
                </div>
                <div class="form-group">
                    <label for="otp">Enter OTP</label>
                    <input type="text" class="form-control" id="otp" name="otp" placeholder="Enter the OTP" required>
                </div>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required>
                </div>
                <div class="form-group text-center">
                    <button type="submit" name="verify_otp" class="btn btn-gradient btn-block" style="padding:5px; width:70%;">Sign Up</button>
                </div>
                <div class="text-center mt-3">
                    <p class="text-muted">Already have an account? <a href="index.php" class="text-primary">Login</a></p>
                </div>
            </form>
        </div>
    </div>

    <div class="copyright_section">
        <p class="copyright_text">&copy; Students Grievance System.</p>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $('#requestOtpButton').click(function() {
            var email = $('#email').val();
            $('#requestOtpButton').prop('disabled', true).text('Sending...');
            $.ajax({
                url: '', // Current page
                method: 'POST',
                data: { action: 'request_otp', email: email },
                success: function(response) {
                    try {
                        var res = JSON.parse(response);
                        if (res.status === 'success') {
                            $('#otp-message').show().text(res.message);
                        } else {
                            alert(res.message);
                        }
                    } catch (e) {
                        console.error("Invalid JSON response:", response);
                    }
                },
                error: function(xhr, status, error) {
                    alert('Failed to send OTP. Please check your internet connection or try again later.');
                }
            });
        });
    </script>
</body>
</html>