<?php
function statusColor($status) {
    $colors = [
        'pending'     => 'warning',
        'in_progress' => 'primary',
        'resolved'    => 'success'
    ];
    return $colors[$status] ?? 'secondary';
}
?>
