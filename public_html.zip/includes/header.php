<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once 'config.php';
include_once 'helpers.php';

// Determine if we're on the login page
$currentPage = basename($_SERVER['SCRIPT_NAME']);
$hideNavbar = ($currentPage === "index.php");

// Initialize notification data
$unreadCount = 0;
$notifications = [];

if (isset($_SESSION['user_role']) && isset($_SESSION['user_id']) && in_array($_SESSION['user_role'], ['admin', 'student'])) {
    try {
        // Validate admin_category for admins
        $admin_category = null;
        if ($_SESSION['user_role'] === 'admin' && isset($_SESSION['admin_category']) && $_SESSION['admin_category'] !== 'main') {
            $stmt = $pdo->prepare("SELECT name FROM categories WHERE name = ?");
            $stmt->execute([$_SESSION['admin_category']]);
            $admin_category = $stmt->fetchColumn();
            if (!$admin_category) {
                error_log("Invalid admin_category: {$_SESSION['admin_category']}");
                $admin_category = null;
            }
        }

        if ($_SESSION['user_role'] === 'admin') {
            if ($admin_category) {
                // Non-main admin: count and fetch notifications for specific category
                $stmt = $pdo->prepare("
                    SELECT m.id, m.message, m.created_at, m.grievance_id, g.title AS grievance_title,
                           (SELECT COUNT(*) FROM messages m2
                            JOIN grievances g2 ON m2.grievance_id = g2.id
                            WHERE m2.sender = 'student'
                              AND m2.is_read = 0
                              AND g2.category = ?
                              AND g2.status IN ('pending', 'in_progress')) AS unread_count
                    FROM messages m
                    JOIN grievances g ON m.grievance_id = g.id
                    WHERE m.sender = 'student'
                      AND m.is_read = 0
                      AND g.category = ?
                      AND g.status IN ('pending', 'in_progress')
                    ORDER BY m.created_at DESC
                ");
                $stmt->execute([$admin_category, $admin_category]);
                $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $unreadCount = !empty($notifications) ? $notifications[0]['unread_count'] : 0;
            } else {
                // Main admin: count and fetch all unread student messages
                $stmt = $pdo->prepare("
                    SELECT m.id, m.message, m.created_at, m.grievance_id, g.title AS grievance_title,
                           (SELECT COUNT(*) FROM messages m2
                            JOIN grievances g2 ON m2.grievance_id = g2.id
                            WHERE m2.sender = 'student'
                              AND m2.is_read = 0
                              AND g2.status IN ('pending', 'in_progress')) AS unread_count
                    FROM messages m
                    JOIN grievances g ON m.grievance_id = g.id
                    WHERE m.sender = 'student'
                      AND m.is_read = 0
                      AND g.status IN ('pending', 'in_progress')
                    ORDER BY m.created_at DESC
                ");
                $stmt->execute();
                $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $unreadCount = !empty($notifications) ? $notifications[0]['unread_count'] : 0;
            }
        } elseif ($_SESSION['user_role'] === 'student') {
            // Student: count and fetch unread admin messages
            $stmt = $pdo->prepare("
                SELECT m.id, m.message, m.created_at, m.grievance_id, g.title AS grievance_title,
                       (SELECT COUNT(*) FROM messages m2
                        JOIN grievances g2 ON m2.grievance_id = g2.id
                        WHERE m2.sender = 'admin'
                          AND m2.is_read = 0
                          AND g2.user_id = ?
                          AND g2.status IN ('pending', 'in_progress')) AS unread_count
                FROM messages m
                JOIN grievances g ON m.grievance_id = g.id
                WHERE m.sender = 'admin'
                  AND m.is_read = 0
                  AND g.user_id = ?
                  AND g.status IN ('pending', 'in_progress')
                ORDER BY m.created_at DESC
            ");
            $stmt->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
            $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $unreadCount = !empty($notifications) ? $notifications[0]['unread_count'] : 0;
        }
    } catch (PDOException $e) {
        error_log("Notification query failed: " . $e->getMessage());
        $unreadCount = 0;
        $notifications = [];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 shrink-to-fit=no">
    <title>Student Grievance System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <!-- FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo (strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false) ? '../' : ''; ?>assets/css/styles.css">
    <style>
        .navbar {
            color: white !important;
        }
        .nav-item {
            color: white !important;
            margin-top: 8px;
        }
        #ai {
            margin-top: -3px !important;
        }
        .badge {
            font-size: 0.65rem;
            padding: 2px 6px;
        }
    </style>
</head>
<body>
<?php if (!$hideNavbar): ?>
<!-- Fixed Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-official shadow-sm fixed-top" style="margin-top:0px; color:white">
    <div class="container-fluid px-3 px-md-5" style="color:white;">
        <!-- Brand -->
        <a class="navbar-brand fw-bold" href="<?php
            if (isset($_SESSION['user_role'])) {
                if ($_SESSION['user_role'] === 'admin') {
                    echo (strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false) ? 'dashboard.php' : 'admin/dashboard.php';
                } else {
                    echo 'dashboard.php';
                }
            } else {
                echo 'index.php';
            }
        ?>" style="color:white;">
            <img src="./assets/images/logo.jpg" alt="Muni University Logo" height="30px" width="30px"></i>MuniSGS
        </a>
        <!-- Toggler for mobile -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Nav Items -->
        <div class="collapse navbar-collapse" id="navbarContent">
            <?php if (isset($_SESSION['user_id'])): ?>
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <?php if ($_SESSION['user_role'] === 'student'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="submit.php">Submit Grievance</a>
                    </li>
                <?php elseif ($_SESSION['user_role'] === 'admin'): ?>
                    <?php if (isset($_SESSION['admin_category']) && $_SESSION['admin_category'] === 'main'): ?>
                        <li class="nav-item me-3">
                            <a href="manage_subadmins.php" class="btn btn-outline-light">
                                <i class="fas fa-users-cog me-2"></i>Manage Sub-Admins
                            </a>
                        </li>
                        <li class="nav-item me-3">
                            <a href="allocate_grievance.php" class="btn btn-outline-light">
                                <i class="fas fa-tasks me-2"></i>Allocate Grievance
                            </a>
                        </li>
                        <li class="nav-item me-3">
                            <a href="generate_report.php" class="btn btn-outline-light">
                                <i class="fas fa-file-pdf me-2"></i>Generate PDF
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav ms-auto">
                <li class="nav-item me-3">
                    <a class="nav-link" id="ai" href="chatbot.php" name="chatbot" style="color:white;" title="Chat with AI">
                        <i class="fas fa-robot fa-lg"></i>
                    </a>
                </li>
                <!-- Bell Icon with Notification Count -->
                <?php if (in_array($_SESSION['user_role'] ?? '', ['admin', 'student'])): ?>
                    <li class="nav-item me-3 position-relative">
                        <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#notificationModal">
                            <i class="fas fa-bell fa-lg" id="bell"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                    <?php echo $unreadCount; ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </li>
                <?php endif; ?>
                <!-- Profile Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php
                            echo htmlspecialchars($_SESSION['user_name'] ?? 'User');
                            echo ' (' . htmlspecialchars($_SESSION['display_name'] ?? 'Unknown') . ')';
                        ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                        <li>
                            <a class="dropdown-item" href="<?php echo (strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false) ? '../change_password.php' : 'change_password.php'; ?>">
                                Change Password
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" href="<?php echo (strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false) ? '../logout.php' : 'logout.php'; ?>">
                                Logout
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
            <?php else: ?>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Login</a>
                    </li>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</nav>
<!-- Notification Modal -->
<div class="modal fade" id="notificationModal" tabindex="-1" aria-labelledby="notificationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="notificationModalLabel">Notifications</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if ($notifications): ?>
                    <ul class="list-group">
                        <?php foreach ($notifications as $note): ?>
                            <li class="list-group-item">
                                <a href="<?php echo (strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false) ? '../chat.php' : 'chat.php'; ?>?grievance_id=<?php echo $note['grievance_id']; ?>">
                                    <strong>Grievance #<?php echo htmlspecialchars($note['grievance_id']); ?>: <?php echo htmlspecialchars($note['grievance_title'] ?: 'Untitled'); ?></strong>
                                </a>
                                <br>
                                <small><?php echo htmlspecialchars(substr($note['message'], 0, 50)); ?>...</small>
                                <br>
                                <small class="text-muted"><?php echo date('M d, Y H:i', strtotime($note['created_at'])); ?></small>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="text-muted">No new notifications.</p>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
</body>
</html>