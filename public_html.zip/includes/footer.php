  <!-- Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Animate.css for animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

    <!-- Feedback Link -->
<!-- Feedback Link in Footer -->
<footer class="mt-5 text-center">
  <a href="#" data-bs-toggle="modal" data-bs-target="#feedbackModal" class="btn btn-outline-primary">
    <i class="fas fa-comment-dots me-1"></i> Give Feedback
  </a>
</footer>

<!-- Feedback Modal -->
<div class="modal fade" id="feedbackModal" tabindex="-1" aria-labelledby="feedbackModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="feedbackModalLabel">We Value Your Feedback</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p class="text-center text-muted mb-3">
          Please fill out this quick form to help us improve the Student Grievance System.
        </p>
        <iframe 
          src="https://docs.google.com/forms/d/e/1FAIpQLSeSXhPOhBwjdfixR0l6NHehZuiAQ8xjPERGMLWpkgaeWjFP5Q/viewform?usp=sharing&amp;embedded=true" 
          width="100%" 
          height="600" 
          frameborder="0" 
          marginheight="0" 
          marginwidth="0">
          Loading…
        </iframe>
      </div>
    </div>
  </div>
</div>



  <!-- Custom JS -->
  <script src="assets/js/scripts.js"></script>
  <footer>
       <center> <p>Copyright &copy; <span id="year"></span> |  Students Grievance System | All rights reserved.</p></center>
    </footer>

    <script>
        // Automatically update the year
        document.getElementById("year").textContent = new Date().getFullYear();
    </script>
  
</body>
</html>
