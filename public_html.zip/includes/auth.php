<?php
include_once 'config.php';

// Process Login
if (isset($_POST['login'])) {
    $login_type = $_POST['login_type'];   // 'student', 'dean', or 'counselor'
    $email      = trim($_POST['email']);
    $password   = $_POST['password'];
    
    // Normalize login_type to match display_name or role
    if ($login_type === 'student') {
        $expectedRole        = 'student';
        $expectedDisplayName = 'Student';
    } elseif ($login_type === 'dean') {
        $expectedRole        = 'admin';
        $expectedDisplayName = 'Dean of Students';
    } elseif ($login_type === 'counselor') {
        $expectedRole        = 'admin';
        $expectedDisplayName = 'Counselor';
    } else {
        $_SESSION['error'] = "Invalid login type selected.";
        header("Location: ../login.php");
        exit;
    }

    // Fetch user record
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        // Check role
        if ($user['role'] !== $expectedRole) {
            $_SESSION['error'] = "Access denied for that user type.";
            header("Location: ../login.php");
            exit;
        }
        // If admin, also check display_name
        if ($expectedRole === 'admin' && $user['display_name'] !== $expectedDisplayName) {
            $_SESSION['error'] = "Access denied. You must login as “{$expectedDisplayName}.”";
            header("Location: ../login.php");
            exit;
        }
        
        // All good—set session
        $_SESSION['user_id']      = $user['id'];
        $_SESSION['user_name']    = $user['name'];
        $_SESSION['user_role']    = $user['role'];           // 'student' or 'admin'
        $_SESSION['display_name'] = $expectedDisplayName;    // 'Student', 'Dean of Students', or 'Counselor'
        
        if ($user['role'] === 'admin') {
            $_SESSION['admin_category'] = $user['admin_category'];
        }
        
        // Redirect to dashboard
        if ($user['role'] === 'admin') {
            header("Location: ../admin/dashboard.php");
        } else {
            header("Location: ../dashboard.php");
        }
        exit;
        
    } else {
        $_SESSION['error'] = "Invalid credentials. Please try again.";
        header("Location: ../login.php");
        exit;
    }
}


// Process Registration for Students
if(isset($_POST['register'])) {
    $name             = trim($_POST['name']);
    $email            = trim($_POST['email']);
    $password         = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    if($password !== $confirm_password) {
        $_SESSION['error'] = "Passwords do not match.";
        header("Location: ../register.php");
        exit;
    }
    
    $hashed = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    
    try {
        $stmt->execute([$name, $email, $hashed]);
        $_SESSION['user_id']   = $pdo->lastInsertId();
        $_SESSION['user_name'] = $name;
        $_SESSION['user_role'] = 'student';
        header("Location: ../dashboard.php");
        exit;
    } catch(PDOException $e) {
        $_SESSION['error'] = "Registration failed. Email might already be in use.";
        header("Location: ../register.php");
        exit;
    }
}

// Protect pages that require login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}
