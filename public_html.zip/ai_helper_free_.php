<?php
// ai_helper_free.php

/**
 * getFreeAIResponse - Calls a free AI chatbot API (e.g., SourceryAI's Free Chatbot API)
 * to generate a reply for the given prompt.
 *
 * @param string $prompt The prompt text for the AI.
 * @return string The AI-generated response or an error message.
 */
function getFreeAIResponse($prompt) {
    // Replace with your actual endpoint URL where you have deployed the free chatbot API.
    $apiUrl = "/ai_helper_free.php
/free-chatbot-api/chatbot?message=" . urlencode($prompt);

    // Use file_get_contents to call the API endpoint.
    $result = file_get_contents($apiUrl);
    if ($result === false) {
        return "Error contacting the Free Chatbot API.";
    }

    $response = json_decode($result, true);
    // Assume the API returns a JSON with a key "reply"
    if (isset($response['reply'])) {
        return trim($response['reply']);
    }
    return "No response from free AI.";
}
?>
