<?php
include '../includes/config.php';
include '../includes/auth.php';
include '../includes/helpers.php';

// Determine filter from query string: all, pending, in_progress, resolved
$filter = $_GET['filter'] ?? 'all';

// Build WHERE clause based on admin role and filter
$whereClauses = [];
$params = [];

// For sub-admins, only show grievances in their category
$userRole = $_SESSION['user_role'] ?? null;
$adminCategory = $_SESSION['admin_category'] ?? null;

if ($userRole === 'admin' && $adminCategory !== 'main') {
    $whereClauses[] = "g.category = ?";
    $params[] = $adminCategory;
}

// If filtering by status (pending, in_progress, resolved), add that condition
if (in_array($filter, ['pending','in_progress','resolved'])) {
    $whereClauses[] = "g.status = ?";
    $params[] = $filter;
}
$whereSQL = $whereClauses ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

// --- Fetch Count Summary ---
try {
    $countStmt = $pdo->prepare("SELECT 
        COUNT(*) as total,
        SUM(g.status='pending') as pending,
        SUM(g.status='in_progress') as in_progress,
        SUM(g.status='resolved') as resolved
      FROM grievances g
      JOIN users u ON g.user_id = u.id
      $whereSQL
    ");
    $countStmt->execute($params);
    $counts = $countStmt->fetch();
} catch (PDOException $e) {
    die("Error fetching counts: " . $e->getMessage());
}

// --- Fetch Grievance List ---
$limit = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] > 0 ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$listStmt = $pdo->prepare("
    SELECT g.id, g.description, g.status, g.created_at, u.name as student_name 
    FROM grievances g
    JOIN users u ON g.user_id = u.id
    $whereSQL
    ORDER BY g.created_at DESC
    LIMIT $limit OFFSET $offset
");
$listStmt->execute($params);
$grievances = $listStmt->fetchAll();

// --- Prepare Chart Data (last 7 days) ---
$chartData = ['labels'=>[], 'pending'=>[], 'in_progress'=>[], 'resolved'=>[]];
$stmt = $pdo->prepare("
    SELECT 
      DATE(created_at) as date,
      SUM(status='pending') as pending,
      SUM(status='in_progress') as in_progress,
      SUM(status='resolved') as resolved
    FROM grievances
    WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    GROUP BY DATE(created_at)
");
$stmt->execute();
$rows = $stmt->fetchAll();
foreach ($rows as $row) {
    $chartData['labels'][] = date('M d', strtotime($row['date']));
    $chartData['pending'][] = $row['pending'] ?? 0;
    $chartData['in_progress'][] = $row['in_progress'] ?? 0;
    $chartData['resolved'][] = $row['resolved'] ?? 0;
}
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid px-3 px-md-5 py-4">
  <h2 class="text-center mb-4">Admin Dashboard</h2>

  <!-- Summary Cards -->
  <div class="row g-3 mb-4">
    <?php 
      // Define card details: key, label, count, and custom style
      $cards = [
        'all'         => ['Total Grievances', $counts['total'],      'background: linear-gradient(135deg, #607d8b, #455a64); color: #fff;'],
        'pending'     => ['Pending',          $counts['pending'],    'background: linear-gradient(135deg, #ffb300, #ffa000); color: #fff;'],
        'in_progress' => ['In Progress',      $counts['in_progress'],'background: linear-gradient(135deg, #42a5f5, #1e88e5); color: #fff;'],
        'resolved'    => ['Resolved',         $counts['resolved'],   'background: linear-gradient(135deg, #66bb6a, #43a047); color: #fff;']
      ];
      foreach ($cards as $key => [$label, $value, $style]):
    ?>
    <div class="col-6 col-md-3">
      <div class="card h-100 shadow-sm border-0" 
           onclick="location.href='?filter=<?= $key ?>'" 
           style="cursor:pointer; <?= $style ?>; transition: transform 0.2s;">
        <div class="card-body d-flex flex-column justify-content-center text-center">
          <h6 class="card-title text-uppercase"><?= $label ?></h6>
          <p class="display-6 mb-0"><?= $value ?></p>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Chart Section -->
  <div class="card mb-4 shadow-sm border-0">
    <div class="card-body" style="position: relative; height:300px;">
      <h5 class="card-title mb-3">Grievance Submissions (Last 7 Days)</h5>
      <canvas id="grievanceChart"></canvas>
    </div>
  </div>

  <!-- Grievances Table -->
  <div class="card shadow-sm border-0">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
            <tr>
              <th>ID</th>
              <th>User</th>
              <th>Message</th>
              <th>Status</th>
              <th>Submitted</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($grievances)): ?>
              <?php foreach ($grievances as $g): ?>
                <tr>
                  <td><?= $g['id'] ?></td>
                  <td><?= htmlspecialchars($g['student_name']) ?></td>
                  <td><?= $g['description'] ?></td>
                  <td><span class="badge bg-<?= statusColor($g['status']) ?>"><?= ucfirst($g['status']) ?></span></td>
                  <td><?= date('M d, Y', strtotime($g['created_at'])) ?></td>
                  <td>
                    <a href="../chat.php?grievance_id=<?= $g['id'] ?>" class="btn btn-sm btn-gradient">Chat</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr><td colspan="6" class="text-center py-4">No grievances found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('grievanceChart').getContext('2d');
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: <?= json_encode($chartData['labels']) ?>,
    datasets: [
      {
        label: 'Pending',
        data: <?= json_encode($chartData['pending']) ?>,
        backgroundColor: 'rgba(255, 179, 0, 0.6)',
        borderColor: 'rgba(255, 179, 0, 1)',
        borderWidth: 1,
        borderRadius: 4
      },
      {
        label: 'In Progress',
        data: <?= json_encode($chartData['in_progress']) ?>,
        backgroundColor: 'rgba(66, 165, 245, 0.6)',
        borderColor: 'rgba(66, 165, 245, 1)',
        borderWidth: 1,
        borderRadius: 4
      },
      {
        label: 'Resolved',
        data: <?= json_encode($chartData['resolved']) ?>,
        backgroundColor: 'rgba(102, 187, 106, 0.6)',
        borderColor: 'rgba(102, 187, 106, 1)',
        borderWidth: 1,
        borderRadius: 4
      }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: { position: 'top', labels: { padding: 15 } },
      tooltip: {
        callbacks: {
          label: ctx => ctx.dataset.label + ': ' + ctx.parsed.y
        }
      }
    },
    scales: {
      y: { beginAtZero: true, ticks: { stepSize: 1 } },
      x: { title: { display: true, text: 'Date' } }
    }
  }
});
</script>
