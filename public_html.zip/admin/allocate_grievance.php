<?php
include '../includes/config.php';
include '../includes/auth.php';

// Only allow main admin access
if($_SESSION['user_role'] !== 'admin' || $_SESSION['admin_category'] !== 'main'){
    header("Location: dashboard.php");
    exit;
}

// Process allocation form submission
if(isset($_POST['allocate'])){
    $grievance_id = $_POST['grievance_id'];
    $subadmin_id  = $_POST['subadmin_id'];
    
    // Update the grievance record with the selected sub-admin
    $stmt = $pdo->prepare("UPDATE grievances SET assigned_admin = ? WHERE id = ?");
    $stmt->execute([$subadmin_id, $grievance_id]);
    
    $_SESSION['message'] = "Grievance allocated successfully.";
    header("Location: allocate_grievance.php");
    exit;
}

// Fetch grievances that are not yet allocated (assigned_admin IS NULL)
$stmt = $pdo->query("SELECT g.*, u.name as student_name 
                     FROM grievances g 
                     JOIN users u ON g.user_id = u.id 
                     WHERE g.assigned_admin IS NULL
                     ORDER BY g.created_at DESC");
$grievances = $stmt->fetchAll();

// Fetch list of sub-admins (excluding the main admin)
$stmt = $pdo->prepare("SELECT id, name, admin_category FROM users WHERE role = 'admin' AND admin_category != 'main' ORDER BY name");
$stmt->execute();
$subadmins = $stmt->fetchAll();
?>
<?php include '../includes/header.php'; ?>
<br> <br><br>

<div class="container">
  <?php if(isset($_SESSION['message'])): ?>
      <div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
  <?php endif; ?>
  
  <h4 class="mb-3">Unallocated Grievances</h4>
  
  <?php if($grievances): ?>
    <table class="table table-hover">
      <thead>
        <tr>
          <th>ID</th>
          <th>Student</th>
          <th>Category</th>
          <th>Submitted On</th>
          <th>Allocate To</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($grievances as $g): ?>
          <tr>
            <td><?php echo $g['id']; ?></td>
            <td><?php echo htmlspecialchars($g['student_name']); ?></td>
            <td><?php echo htmlspecialchars($g['category']); ?></td>
            <td><?php echo date('M d, Y', strtotime($g['created_at'])); ?></td>
            <td>
              <form method="POST" class="d-flex">
                <input type="hidden" name="grievance_id" value="<?php echo $g['id']; ?>">
                <select name="subadmin_id" class="form-select form-select-sm" required>
                  <option value="">Select Sub-Admin</option>
                  <?php foreach($subadmins as $admin): ?>
                    <option value="<?php echo $admin['id']; ?>">
                      <?php echo htmlspecialchars($admin['name'] . " (" . ucfirst($admin['admin_category']) . ")"); ?>
                    </option>
                  <?php endforeach; ?>
                </select>
            </td>
            <td>
                <button type="submit" name="allocate" class="btn btn-sm btn-primary">Allocate</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p class="text-muted">No unallocated grievances found.</p>
  <?php endif; ?>
  
  <div class="mt-3">
    <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
