<?php
include '../includes/config.php';
include '../includes/auth.php';

// Only allow the main admin to access this page
if($_SESSION['user_role'] !== 'admin' || $_SESSION['admin_category'] !== 'main'){
    header("Location: dashboard.php");
    exit;
}

// Process adding a new admin
if(isset($_POST['add_admin'])){
    $name             = trim($_POST['name']);
    $email            = trim($_POST['email']);
    $password         = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $category         = trim($_POST['category']); // e.g., academic, hostel, health, bullying
    
    if($password !== $confirm_password){
        $_SESSION['error'] = "Passwords do not match.";
        header("Location: manage_admins.php");
        exit;
    }
    
    $hashed = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, admin_category) VALUES (?, ?, ?, 'admin', ?)");
    try {
        $stmt->execute([$name, $email, $hashed, $category]);
        $_SESSION['message'] = "New admin added successfully!";
        header("Location: manage_admins.php");
        exit;
    } catch(PDOException $e) {
        $_SESSION['error'] = "Failed to add admin. Email might already be in use.";
        header("Location: manage_admins.php");
        exit;
    }
}

// Fetch all admin users except the main admin
$stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'admin' AND admin_category != 'main'");
$stmt->execute();
$admins = $stmt->fetchAll();
?>
<?php include '../includes/header.php'; ?>

<nav class="navbar navbar-glass p-3 mb-4">
  <div class="container">
    <a class="navbar-brand" href="#">Manage Admins</a>
    <div class="d-flex align-items-center">
      <a href="../logout.php" class="btn btn-gradient">Logout</a>
    </div>
  </div>
</nav>

<div class="container">
  <?php if(isset($_SESSION['error'])): ?>
      <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
  <?php endif; ?>
  <?php if(isset($_SESSION['message'])): ?>
      <div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
  <?php endif; ?>
  
  <!-- Form to add a new admin -->
  <div class="card p-4 mb-4">
    <h4>Add New Admin</h4>
    <form method="POST">
      <div class="mb-3">
        <input type="text" name="name" class="form-control" placeholder="Admin Full Name" required>
      </div>
      <div class="mb-3">
        <input type="email" name="email" class="form-control" placeholder="Admin Email" required>
      </div>
      <div class="mb-3">
        <select name="category" class="form-select" required>
          <option value="">Select Admin Category</option>
          <option value="academic">Academic</option>
          <option value="hostel">Hostel</option>
          <option value="health">Health</option>
          <option value="bullying">Bullying</option>
          <!-- You can add more categories as needed -->
        </select>
      </div>
      <div class="mb-3">
        <input type="password" name="password" class="form-control" placeholder="Password" required>
      </div>
      <div class="mb-3">
        <input type="password" name="confirm_password" class="form-control" placeholder="Confirm Password" required>
      </div>
      <button type="submit" name="add_admin" class="btn-gradient">Add Admin</button>
    </form>
  </div>
  
  <!-- List of assigned admins and their activity -->
  <div class="card p-4">
    <h4>Assigned Admins</h4>
    <table class="table table-hover">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Category</th>
          <th>Activity</th>
        </tr>
      </thead>
      <tbody>
        <?php if($admins): ?>
          <?php foreach($admins as $admin): ?>
            <tr>
              <td><?php echo htmlspecialchars($admin['name']); ?></td>
              <td><?php echo htmlspecialchars($admin['email']); ?></td>
              <td><?php echo htmlspecialchars($admin['admin_category']); ?></td>
              <td>
                <!-- Placeholder for activity data (e.g., number of grievances solved) -->
                <?php 
                  // Example: if you have a column in grievances like assigned_admin,
                  // count how many tasks have been assigned to this admin.
                  $stmt = $pdo->prepare("SELECT COUNT(*) FROM grievances WHERE assigned_admin = ?");
                  $stmt->execute([$admin['id']]);
                  echo $stmt->fetchColumn() . " tasks";
                ?>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="4" class="text-center">No admins assigned yet.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
