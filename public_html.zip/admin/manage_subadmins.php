<?php
include '../includes/config.php';
include '../includes/auth.php';

// Check if user is admin (either main or sub-admin)
if($_SESSION['user_role'] !== 'admin'){
    header("Location: dashboard.php");
    exit;
}

// Process form for adding sub-admin
if(isset($_POST['add_subadmin']) && $_SESSION['admin_category'] === 'main'){
    $name              = trim($_POST['name']);
    $email             = trim($_POST['email']);
    $password          = $_POST['password'];
    $confirm_password  = $_POST['confirm_password'];
    $categories        = $_POST['categories'] ?? []; // Array of selected categories

    if($password !== $confirm_password){
        $_SESSION['error'] = "Passwords do not match.";
        header("Location: manage_subadmins.php");
        exit;
    }
    
    if(empty($categories)){
        $_SESSION['error'] = "Please select at least one category.";
        header("Location: manage_subadmins.php");
        exit;
    }
    
    $hashed = password_hash($password, PASSWORD_BCRYPT);
    
    // Start transaction
    $pdo->beginTransaction();
    
    try {
        // First insert the user
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, admin_category) VALUES (?, ?, ?, 'admin', 'subadmin')");
        $stmt->execute([$name, $email, $hashed]);
        $user_id = $pdo->lastInsertId();
        
        // Then insert category assignments
        $stmt = $pdo->prepare("INSERT INTO admin_categories (admin_id, category_id) VALUES (?, ?)");
        foreach($categories as $category_id){
            $stmt->execute([$user_id, $category_id]);
        }
        
        $pdo->commit();
        $_SESSION['message'] = "Sub-admin added successfully with categories assigned!";
    } catch(PDOException $e){
        $pdo->rollBack();
        $_SESSION['error'] = "Failed to add sub-admin. Error: " . $e->getMessage();
    }
    
    header("Location: manage_subadmins.php");
    exit;
}

// Process category allocation to existing sub-admin
if(isset($_POST['allocate_categories']) && $_SESSION['admin_category'] === 'main'){
    $admin_id = intval($_POST['admin_id']);
    $categories = $_POST['categories'] ?? [];
    
    if(empty($categories)){
        $_SESSION['error'] = "Please select at least one category.";
        header("Location: manage_subadmins.php");
        exit;
    }
    
    // Start transaction
    $pdo->beginTransaction();
    
    try {
        // First remove existing assignments
        $stmt = $pdo->prepare("DELETE FROM admin_categories WHERE admin_id = ?");
        $stmt->execute([$admin_id]);
        
        // Then add new assignments
        $stmt = $pdo->prepare("INSERT INTO admin_categories (admin_id, category_id) VALUES (?, ?)");
        foreach($categories as $category_id){
            $stmt->execute([$admin_id, $category_id]);
        }
        
        $pdo->commit();
        $_SESSION['message'] = "Categories allocated successfully!";
    } catch(PDOException $e){
        $pdo->rollBack();
        $_SESSION['error'] = "Failed to allocate categories. Error: " . $e->getMessage();
    }
    
    header("Location: manage_subadmins.php");
    exit;
}

// Fetch all sub-admins with their categories (only for main admin)
if($_SESSION['admin_category'] === 'main'){
    // Get all sub-admins
    $stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'admin' AND admin_category = 'subadmin' ORDER BY name");
    $stmt->execute();
    $subadmins = $stmt->fetchAll();
    
    // Get categories for each sub-admin
    foreach($subadmins as &$admin){
        $stmt = $pdo->prepare("
            SELECT c.id, c.name 
            FROM categories c
            JOIN admin_categories ac ON c.id = ac.category_id
            WHERE ac.admin_id = ?
        ");
        $stmt->execute([$admin['id']]);
        $admin['categories'] = $stmt->fetchAll();
    }
    unset($admin); // Break the reference
} else {
    $subadmins = [];
}

// Get current admin's categories if they're a sub-admin
$current_admin_categories = [];
if($_SESSION['admin_category'] === 'subadmin'){
    $stmt = $pdo->prepare("
        SELECT c.id, c.name 
        FROM categories c
        JOIN admin_categories ac ON c.id = ac.category_id
        WHERE ac.admin_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $current_admin_categories = $stmt->fetchAll();
}

// Get grievances count for the current sub-admin (if not main admin)
$grievances_count = 0;
if($_SESSION['admin_category'] === 'subadmin' && !empty($current_admin_categories)){
    $category_ids = array_column($current_admin_categories, 'id');
    $placeholders = implode(',', array_fill(0, count($category_ids), '?'));
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM grievances WHERE category_id IN ($placeholders)");
    $stmt->execute($category_ids);
    $result = $stmt->fetch();
    $grievances_count = $result['total'];
}

// Fetch all categories (only for main admin)
if($_SESSION['admin_category'] === 'main'){
    $stmt = $pdo->prepare("SELECT * FROM categories ORDER BY name");
    $stmt->execute();
    $all_categories = $stmt->fetchAll();
} else {
    $all_categories = [];
}

// Add a new category (only for main admin)
if (isset($_POST['add_category']) && $_SESSION['admin_category'] === 'main') {
    $name = trim($_POST['category_name']);
    $description = trim($_POST['category_description']);

    if (empty($name)) {
        $_SESSION['error'] = "Category name is required.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
        try {
            $stmt->execute([$name, $description]);
            $_SESSION['message'] = "Category added successfully!";
        } catch (PDOException $e) {
            $_SESSION['error'] = "Failed to add category. Category name might already exist.";
        }
    }
    header("Location: manage_subadmins.php");
    exit;
}

// Delete a category (only for main admin)
if (isset($_GET['delete_category']) && $_SESSION['admin_category'] === 'main') {
    $category_id = intval($_GET['delete_category']);

    // Check if the category is in use
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM admin_categories WHERE category_id = ?");
    $stmt->execute([$category_id]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        $_SESSION['error'] = "Cannot delete category. It is assigned to one or more sub-admins.";
    } else {
        $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->execute([$category_id]);
        $_SESSION['message'] = "Category deleted successfully!";
    }
    header("Location: manage_subadmins.php");
    exit;
}
?>
<?php include '../includes/header.php'; ?>

<br><br><br>

<div class="container">
  <?php if(isset($_SESSION['error'])): ?>
      <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
  <?php endif; ?>
  <?php if(isset($_SESSION['message'])): ?>
      <div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
  <?php endif; ?>
  
  <!-- Dashboard Cards -->
  <div class="row mb-4">
    <?php if($_SESSION['admin_category'] === 'subadmin'): ?>
      <div class="col-md-4">
        <div class="card text-white bg-primary mb-3">
          <div class="card-body">
            <h5 class="card-title">All Grievances</h5>
            <p class="card-text display-4"><?php echo $grievances_count; ?></p>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>
  
  <!-- Form to Add a New Sub-Admin (only for main admin) -->
  <?php if($_SESSION['admin_category'] === 'main'): ?>
    <div class="card p-4 mb-4">
      <h4>Add New Sub-Admin</h4>
      <form method="POST">
        <div class="mb-3">
          <input type="text" name="name" class="form-control" placeholder="Sub-Admin Full Name" required>
        </div>
        <div class="mb-3">
          <input type="email" name="email" class="form-control" placeholder="Sub-Admin Email" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Assign Categories</label>
          <?php foreach($all_categories as $category): ?>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" name="categories[]" value="<?php echo $category['id']; ?>" id="cat_<?php echo $category['id']; ?>">
              <label class="form-check-label" for="cat_<?php echo $category['id']; ?>">
                <?php echo htmlspecialchars($category['name']); ?>
              </label>
            </div>
          <?php endforeach; ?>
        </div>
        <div class="mb-3">
          <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        <div class="mb-3">
          <input type="password" name="confirm_password" class="form-control" placeholder="Confirm Password" required>
        </div>
        <button type="submit" name="add_subadmin" class="btn-gradient">Add Sub-Admin</button>
      </form>
    </div>
  <?php endif; ?>
  
  <!-- Sub-Admins with Assigned Categories (only for main admin) -->
  <?php if($_SESSION['admin_category'] === 'main'): ?>
    <div class="card p-4 mb-4">
      <h4>Sub-Admins and Their Categories</h4>
      <div class="table-responsive" style="overflow-x: auto;">
        <table class="table table-hover" style="min-width: 800px;">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Grievances Resolved</th>
              <th>Assigned Categories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if($subadmins): ?>
              <?php foreach($subadmins as $admin): ?>
                <tr>
                  <td><?php echo htmlspecialchars($admin['name']); ?></td>
                  <td><?php echo htmlspecialchars($admin['email']); ?></td>
                  <td><?php echo isset($activity[$admin['id']]) ? $activity[$admin['id']] : 0; ?></td>
                  <td>
                    <?php if(!empty($admin['categories'])): ?>
                      <?php foreach($admin['categories'] as $category): ?>
                        <span class="badge bg-primary me-1"><?php echo htmlspecialchars($category['name']); ?></span>
                      <?php endforeach; ?>
                    <?php else: ?>
                      <span class="text-muted">No categories assigned</span>
                    <?php endif; ?>
                  </td>
                  
                  <td>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#allocateModal<?php echo $admin['id']; ?>">
                      Edit Categories
                    </button>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="5" class="text-center">No sub-admins found.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modals for category allocation -->
    <?php if($subadmins): ?>
      <?php foreach($subadmins as $admin): ?>
        <div class="modal fade" id="allocateModal<?php echo $admin['id']; ?>" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">Allocate Categories to <?php echo htmlspecialchars($admin['name']); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <form method="POST">
                <div class="modal-body">
                  <input type="hidden" name="admin_id" value="<?php echo $admin['id']; ?>">
                  <?php foreach($all_categories as $category): ?>
                    <div class="form-check">
                      <input class="form-check-input" type="checkbox" name="categories[]" 
                            value="<?php echo $category['id']; ?>" 
                            id="admin_<?php echo $admin['id']; ?>_cat_<?php echo $category['id']; ?>"
                            <?php 
                              // Check if this category is assigned to the admin
                              $assigned = false;
                              foreach($admin['categories'] as $assigned_cat){
                                if($assigned_cat['id'] == $category['id']){
                                  $assigned = true;
                                  break;
                                }
                              }
                              echo $assigned ? 'checked' : '';
                            ?>>
                      <label class="form-check-label" for="admin_<?php echo $admin['id']; ?>_cat_<?php echo $category['id']; ?>">
                        <?php echo htmlspecialchars($category['name']); ?>
                      </label>
                    </div>
                  <?php endforeach; ?>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="submit" name="allocate_categories" class="btn btn-primary">Save Changes</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  <?php endif; ?>
  
  <!-- Add Category Form (only for main admin) -->
  <?php if($_SESSION['admin_category'] === 'main'): ?>
    <div class="card p-4 mb-4">
      <h4>Add New Category</h4>
      <form method="POST">
        <div class="mb-3">
          <input type="text" name="category_name" class="form-control" placeholder="Category Name" required>
        </div>
        <div class="mb-3">
          <textarea name="category_description" class="form-control" placeholder="Category Description"></textarea>
        </div>
        <button type="submit" name="add_category" class="btn-gradient">Add Category</button>
      </form>
    </div>
  <?php endif; ?>
  
  <!-- List of Categories (only for main admin) -->
  <?php if($_SESSION['admin_category'] === 'main'): ?>
    <div class="card p-4">
      <h4>All Categories</h4>
      <div class="table-responsive" style="overflow-x: auto;">
        <table class="table table-hover" style="min-width: 600px;">
          <thead>
            <tr>
              <th>Name</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($all_categories): ?>
              <?php foreach ($all_categories as $category): ?>
                <tr>
                  <td><?php echo htmlspecialchars($category['name']); ?></td>
                  <td><?php echo htmlspecialchars($category['description']); ?></td>
                  <td>
                    <a href="?delete_category=<?php echo $category['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this category?');">Delete</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="3" class="text-center">No categories found.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>