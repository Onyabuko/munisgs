<?php
// session_start();
include '../includes/config.php';
include '../includes/auth.php';
include '../includes/helpers.php';

// Ensure admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Get grievance ID from URL
if (!isset($_GET['id'])) {
    $_SESSION['error'] = "No grievance selected.";
    header("Location: dashboard.php");
    exit;
}

$grievance_id = $_GET['id'];

// Fetch grievance details
$stmt = $pdo->prepare("SELECT * FROM grievances WHERE id = ?");
$stmt->execute([$grievance_id]);
$grievance = $stmt->fetch();

if (!$grievance) {
    $_SESSION['error'] = "Grievance not found.";
    header("Location: dashboard.php");
    exit;
}

// Fetch chat messages related to this grievance
$msg_stmt = $pdo->prepare("SELECT * FROM messages WHERE grievance_id = ? ORDER BY timestamp ASC");
$msg_stmt->execute([$grievance_id]);
$messages = $msg_stmt->fetchAll();

// Handle admin reply
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply'])) {
    $reply_text = trim($_POST['reply_text']);

    if (!empty($reply_text)) {
        // Insert message into database
        $insert_stmt = $pdo->prepare("INSERT INTO messages (grievance_id, sender, message) VALUES (?, 'admin', ?)");
        $insert_stmt->execute([$grievance_id, $reply_text]);

        // Update grievance status to 'solved'
        $update_stmt = $pdo->prepare("UPDATE grievances SET status = 'solved' WHERE id = ?");
        $update_stmt->execute([$grievance_id]);

        // Refresh page to show the new message
        header("Location: grievance_details.php?id=" . $grievance_id);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grievance Details</title>
    <link rel="stylesheet" href="../styles.css"> <!-- Add your styles if needed -->
</head>
<body>
    <h2>Grievance Details</h2>
    <p><strong>Category:</strong> <?php echo htmlspecialchars($grievance['category']); ?></p>
    <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($grievance['description'])); ?></p>
    <p><strong>Status:</strong> <span style="color:<?php echo $grievance['status'] === 'solved' ? 'green' : 'red'; ?>"><?php echo ucfirst($grievance['status']); ?></span></p>

    <h3>Chat with Student</h3>
    <div style="border: 1px solid #ddd; padding: 10px; max-height: 300px; overflow-y: scroll;">
        <?php foreach ($messages as $msg): ?>
            <p><strong><?php echo $msg['sender'] === 'admin' ? 'You (Admin)' : 'Student'; ?>:</strong> <?php echo nl2br(htmlspecialchars($msg['message'])); ?></p>
        <?php endforeach; ?>
    </div>

    <form method="post">
        <textarea name="reply_text" rows="3" required placeholder="Type your reply..."></textarea><br>
        <button type="submit" name="reply">Send Reply</button>
    </form>

    <br>
    <a href="dashboard.php">Back to Dashboard</a>
</body>
</html
