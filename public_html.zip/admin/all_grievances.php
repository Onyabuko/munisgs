<?php
include '../includes/config.php';
include '../includes/auth.php';
include '../includes/helpers.php';

if (!isset($_SESSION['user_role']) || !isset($_SESSION['admin_category'])) {
    $_SESSION['error'] = "Session variables are not set.";
    header("Location: login.php");
    exit;
}

// --- Determine Which Grievances to Fetch Based on Admin Role ---
try {
    $limit = 10; // Number of grievances per page
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($page - 1) * $limit;

    if ($_SESSION['user_role'] === 'admin' && $_SESSION['admin_category'] !== 'main') {
        // Sub-admin: show grievances only for their category
        $stmt = $pdo->prepare("SELECT g.*, u.name as student_name 
                               FROM grievances g 
                               JOIN users u ON g.user_id = u.id 
                               WHERE g.category = ? 
                               ORDER BY g.created_at DESC 
                               LIMIT ? OFFSET ?");
        $stmt->execute([$_SESSION['admin_category'], $limit, $offset]);
    } else {
        // Main admin: show all grievances
        $stmt = $pdo->prepare("SELECT g.*, u.name as student_name 
                               FROM grievances g 
                               JOIN users u ON g.user_id = u.id 
                               ORDER BY g.created_at DESC 
                               LIMIT ? OFFSET ?");
        $stmt->execute([$limit, $offset]);
    }
    $grievances = $stmt->fetchAll();
} catch (PDOException $e) {
    $grievances = [];
    error_log("Database Error: " . $e->getMessage(), 3, '../logs/error.log');
    $_SESSION['error'] = "Error fetching grievances: " . $e->getMessage();
}

// --- Count Grievances per Status (Filtered for Sub-Admins) ---
try {
    if ($_SESSION['user_role'] === 'admin' && $_SESSION['admin_category'] !== 'main') {
        $stmt = $pdo->prepare("SELECT status, COUNT(*) as count 
                               FROM grievances 
                               WHERE category = ? 
                               GROUP BY status");
        $stmt->execute([$_SESSION['admin_category']]);
    } else {
        $stmt = $pdo->query("SELECT status, COUNT(*) as count 
                             FROM grievances 
                             GROUP BY status");
    }
    $statusCounts = [
        'pending'     => 0,
        'in_progress' => 0,
        'resolved'    => 0
    ];
    while ($row = $stmt->fetch()) {
        $statusCounts[$row['status']] = $row['count'];
    }
} catch (PDOException $e) {
    $statusCounts = ['pending' => 0, 'in_progress' => 0, 'resolved' => 0];
    error_log("Database Error: " . $e->getMessage(), 3, '../logs/error.log');
    $_SESSION['error'] = "Error counting statuses: " . $e->getMessage();
}

// --- Process Status Update ---
if (isset($_POST['update_status'])) {
    $grievance_id = $_POST['grievance_id'];
    $new_status   = $_POST['status'];
    try {
        $stmt = $pdo->prepare("UPDATE grievances SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $grievance_id]);
        $_SESSION['message'] = "Grievance status updated.";
    } catch (PDOException $e) {
        error_log("Database Error: " . $e->getMessage(), 3, '../logs/error.log');
        $_SESSION['error'] = "Error updating status: " . $e->getMessage();
    }
    header("Location: dashboard.php");
    exit;
}
?>
<style>
.navbar{
  /*margin-top:-4px !important;*/
  width:100%;

}
tr{
  width:auto;
}
#ai{
  margin-top:12px !important;
}
</style>
<!-- Include the single nav bar (with notification bell) from your header -->
<?php include '../includes/header.php'; ?>
<br>br
<!-- all grievances -->


<div class="container py-3">
  <h2 class="mb-4">All Grievances</h2>
  <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
  <?php endif; ?>
  <?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
  <?php endif; ?>

  <?php if (!empty($grievances)): ?>
    <table class="table table-hover">
      <thead>
        <tr>
          <th>ID</th>
          <th>User</th>
          <th>Title</th>
          <th>Description</th>
          <th>Status</th>
          <th>Submitted</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($grievances as $g): ?>
          <tr>
            <td><?php echo $g['id']; ?></td>
            <td><?php echo htmlspecialchars($g['student_name']); ?></td>
            <td><?php echo htmlspecialchars($g['title']); ?></td>
            <td><?php echo htmlspecialchars($g['description']); ?></td>
            <td>
              <form method="POST">
                <input type="hidden" name="grievance_id" value="<?php echo $g['id']; ?>">
                <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                  <option value="pending" <?php echo ($g['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                  <option value="in_progress" <?php echo ($g['status'] == 'in_progress') ? 'selected' : ''; ?>>In Progress</option>
                  <option value="resolved" <?php echo ($g['status'] == 'resolved') ? 'selected' : ''; ?>>Resolved</option>
                </select>
                <noscript>
                  <button type="submit" name="update_status" class="btn btn-primary btn-sm">Update</button>
                </noscript>
              </form>
            </td>
            <td><?php echo date('M d, Y', strtotime($g['created_at'])); ?></td>
            <td>
              <a href="../chat.php?grievance_id=<?php echo urlencode($g['id']); ?>" class="btn btn-sm btn-primary">
                Chat
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <div class="alert alert-info">No grievances found for your category.</div>
  <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
