<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dynamic Copyright Year</title>
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Custom JS -->
    <script src="assets/js/scripts.js"></script>
</head>
<body>

    <?php
    // Database connection
    $conn = new mysqli("localhost", "username", "password", "database_name");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query to count grievances
    $sql = "SELECT COUNT(*) AS total_grievances FROM grievances";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $grievance_count = $row['total_grievances'];

    $conn->close();
    ?>

    <div class="col-md-4">
        <div class="card text-white bg-variant mb-3" style="background-color:#F15B42; padding-bottom:8px;">
            <a href="all_grievances.php">
                <div class="card-body">
                    <center>
                        <h5 class="card-title"><i class="fas fa-clock"></i> All Grievances</h5>
                        <p class="card-text">Total: <?php echo $grievance_count; ?></p>
                    </center>
                </div>
            </a>
        </div>
    </div>

    <footer>
        <center><p>&copy; <span id="year"></span> Students Grievance System. All rights reserved.</p></center>
    </footer>

    <script>
        // Automatically update the year
        document.getElementById("year").textContent = new Date().getFullYear();
    </script>

</body>
</html>
