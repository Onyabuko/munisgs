<?php
include '../includes/config.php';
include '../includes/auth.php';

// Only allow main admin access
if($_SESSION['user_role'] !== 'admin' || $_SESSION['admin_category'] !== 'main'){
    header("Location: dashboard.php");
    exit;
}

// Process form for adding sub-admin
if(isset($_POST['add_subadmin'])){
    $name              = trim($_POST['name']);
    $email             = trim($_POST['email']);
    $password          = $_POST['password'];
    $confirm_password  = $_POST['confirm_password'];
    $category          = trim($_POST['category']); // Expected values: education, health, bullying, religious, hostel

    if($password !== $confirm_password){
        $_SESSION['error'] = "Passwords do not match.";
        header("Location: manage_subadmins.php");
        exit;
    }
    
    $hashed = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, admin_category) VALUES (?, ?, ?, 'admin', ?)");
    try{
        $stmt->execute([$name, $email, $hashed, $category]);
        $_SESSION['message'] = "Sub-admin added successfully!";
        header("Location: manage_subadmins.php");
        exit;
    } catch(PDOException $e){
        $_SESSION['error'] = "Failed to add sub-admin. Email might already be in use.";
        header("Location: manage_subadmins.php");
        exit;
    }
}

// Fetch all sub-admins (excluding the main admin)
$stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'admin' AND admin_category != 'main' ORDER BY admin_category, name");
$stmt->execute();
$subadmins = $stmt->fetchAll();

// Analysis: Count resolved grievances for each sub-admin
$activity = [];
foreach($subadmins as $admin){
    // Assumes the grievances table has an assigned_admin column
    $stmt = $pdo->prepare("SELECT COUNT(*) as resolved_count FROM grievances WHERE assigned_admin = ? AND status = 'resolved'");
    $stmt->execute([$admin['id']]);
    $result = $stmt->fetch();
    $activity[$admin['id']] = $result['resolved_count'];
}

// Summary Analysis per category
$categorySummary = [];
$categories = ['education', 'health', 'bullying', 'religious', 'hostel'];
foreach($categories as $cat){
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_resolved 
        FROM grievances 
        WHERE assigned_admin IN (
            SELECT id FROM users WHERE role = 'admin' AND admin_category = ?
        ) 
        AND status = 'resolved'
    ");
    $stmt->execute([$cat]);
    $result = $stmt->fetch();
    $categorySummary[$cat] = $result['total_resolved'];
}

// Add a new category
if (isset($_POST['add_category'])) {
  $name = trim($_POST['category_name']);
  $description = trim($_POST['category_description']);

  if (empty($name)) {
      $_SESSION['error'] = "Category name is required.";
  } else {
      $stmt = $pdo->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
      try {
          $stmt->execute([$name, $description]);
          $_SESSION['message'] = "Category added successfully!";
      } catch (PDOException $e) {
          $_SESSION['error'] = "Failed to add category. Category name might already exist.";
      }
  }
  header("Location: manage_subadmins.php");
  exit;
}

// Delete a category
if (isset($_GET['delete_category'])) {
  $category_id = intval($_GET['delete_category']);

  // Check if the category is in use
  $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE admin_category = ?");
  $stmt->execute([$category_id]);
  $count = $stmt->fetchColumn();

  if ($count > 0) {
      $_SESSION['error'] = "Cannot delete category. It is assigned to one or more sub-admins.";
  } else {
      $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
      $stmt->execute([$category_id]);
      $_SESSION['message'] = "Category deleted successfully!";
  }
  header("Location: manage_subadmins.php");
  exit;
}

// Fetch all categories
$stmt = $pdo->prepare("SELECT * FROM categories");
$stmt->execute();
$categories = $stmt->fetchAll();

// Summary Analysis per category
$categorySummary = [];
foreach ($categories as $cat) {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_resolved 
        FROM grievances 
        WHERE assigned_admin IN (
            SELECT id FROM users WHERE role = 'admin' AND admin_category = ?
        ) 
        AND status = 'resolved'
    ");
    $stmt->execute([$cat['name']]);
    $result = $stmt->fetch();
    $categorySummary[$cat['name']] = $result['total_resolved'];
}
?>
<?php include '../includes/header.php'; ?>

<br><br><br>

<div class="container">
  <?php if(isset($_SESSION['error'])): ?>
      <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
  <?php endif; ?>
  <?php if(isset($_SESSION['message'])): ?>
      <div class="alert alert-success"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
  <?php endif; ?>
  
  <!-- Form to Add a New Sub-Admin -->
  <div class="card p-4 mb-4">
    <h4>Add New Sub-Admin</h4>
    <form method="POST">
      <div class="mb-3">
        <input type="text" name="name" class="form-control" placeholder="Sub-Admin Full Name" required>
      </div>
      <div class="mb-3">
        <input type="email" name="email" class="form-control" placeholder="Sub-Admin Email" required>
      </div>
      <div class="mb-3">
        <select name="category" class="form-select" required>
          <option value="">Select Category</option>
          <option value="education">Education</option>
          <option value="health">Health</option>
          <option value="bullying">Bullying</option>
          <option value="religious">Religious</option>
          <option value="hostel">Hostel</option>
        </select>
      </div>
      <div class="mb-3">
        <input type="password" name="password" class="form-control" placeholder="Password" required>
      </div>
      <div class="mb-3">
        <input type="password" name="confirm_password" class="form-control" placeholder="Confirm Password" required>
      </div>
      <button type="submit" name="add_subadmin" class="btn-gradient">Add Sub-Admin</button>
    </form>
  </div>
  
  <!-- List of Sub-Admins and Their Activity -->
  <div class="card p-4 mb-4">
    <h4>Sub-Admins Activity</h4>
    <table class="table table-hover">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Category</th>
          <th>Grievances Resolved</th>
        </tr>
      </thead>
      <tbody>
        <?php if($subadmins): ?>
          <?php foreach($subadmins as $admin): ?>
            <tr>
              <td><?php echo htmlspecialchars($admin['name']); ?></td>
              <td><?php echo htmlspecialchars($admin['email']); ?></td>
              <td><?php echo htmlspecialchars(ucfirst($admin['admin_category'])); ?></td>
              <td><?php echo isset($activity[$admin['id']]) ? $activity[$admin['id']] : 0; ?></td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="4" class="text-center">No sub-admins found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  


  
    <!-- Add Category Form -->
    <div class="card p-4 mb-4">
        <h4>Add New Category</h4>
        <form method="POST">
            <div class="mb-3">
                <input type="text" name="category_name" class="form-control" placeholder="Category Name" required>
            </div>
            <div class="mb-3">
                <textarea name="category_description" class="form-control" placeholder="Category Description"></textarea>
            </div>
            <button type="submit" name="add_category" class="btn-gradient">Add Category</button>
        </form>
    </div>

  
    <!-- List of Categories -->
    <div class="card p-4 mb-4">
        <h4>Categories</h4>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($categories): ?>
                    <?php foreach ($categories as $category): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($category['name']); ?></td>
                            <td><?php echo htmlspecialchars($category['description']); ?></td>
                            <td>
                                <a href="?delete_category=<?php echo $category['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this category?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" class="text-center">No categories found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>


  <!-- Summary Analysis Section -->
  <div class="card p-4">
    <h4>Category Summary</h4>
    <ul class="list-group">
      <?php foreach($categorySummary as $cat => $total): ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
          <?php echo ucfirst($cat); ?>
          <span class="badge bg-primary rounded-pill"><?php echo $total; ?></span>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
</div>

<?php include '../includes/footer.php'; ?>
