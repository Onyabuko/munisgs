<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../includes/config.php';
include '../includes/auth.php';
include '../includes/helpers.php';

// Include FPDF library
require_once '../includes/fpdf/fpdf.php';

// Restrict access to main admins
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin' || !isset($_SESSION['admin_category']) || $_SESSION['admin_category'] !== 'main') {
    header('Location: index.php');
    exit;
}

// Initialize filter variables
$start_date = $_POST['start_date'] ?? '';
$end_date = $_POST['end_date'] ?? '';
$month = $_POST['month'] ?? '';
$name = $_POST['name'] ?? '';
$grievances = [];

// Build the query
try {
    $query = "
        SELECT g.id, g.title, g.category, g.description, g.status, g.created_at, u.name AS user_name
        FROM grievances g
        JOIN users u ON g.user_id = u.id
        WHERE 1=1
    ";
    $params = [];

    // Date range filter
    if ($start_date && $end_date) {
        $query .= " AND g.created_at BETWEEN ? AND ?";
        $params[] = $start_date . ' 00:00:00';
        $params[] = $end_date . ' 23:59:59';
    }

    // Month filter
    if ($month && preg_match('/^\d{4}-\d{2}$/', $month)) {
        $query .= " AND DATE_FORMAT(g.created_at, '%Y-%m') = ?";
        $params[] = $month;
    }

    // Name filter
    if ($name) {
        $query .= " AND u.name LIKE ?";
        $params[] = "%$name%";
    }

    $query .= " ORDER BY g.created_at DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $grievances = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching grievances: " . $e->getMessage());
    $grievances = [];
}

// Handle PDF generation
if (isset($_POST['generate_pdf']) && !empty($grievances)) {
    // Create new FPDF object
    $pdf = new FPDF('P', 'mm', 'A4');
    $pdf->AddPage();

    // Set font for header
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Grievance Report', 0, 1, 'C');
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Muni University Grievance System', 0, 1, 'C');
    $pdf->Cell(0, 10, 'Generated on ' . date('Y-m-d'), 0, 1, 'C');
    $pdf->Ln(5);

    // Filter details
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Filters Applied:', 0, 1);
    $pdf->SetFont('Arial', '', 10);
    if ($start_date && $end_date) {
        $pdf->Cell(0, 6, "Date Range: $start_date to $end_date", 0, 1);
    }
    if ($month) {
        $pdf->Cell(0, 6, "Month: $month", 0, 1);
    }
    if ($name) {
        $pdf->Cell(0, 6, "User Name: $name", 0, 1);
    }
    $pdf->Ln(5);

    // Table header
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->SetFillColor(200, 200, 200);
    $pdf->Cell(15, 10, 'ID', 1, 0, 'C', 1);
    $pdf->Cell(30, 10, 'Title', 1, 0, 'C', 1);
    $pdf->Cell(30, 10, 'Category', 1, 0, 'C', 1);
    $pdf->Cell(50, 10, 'Description', 1, 0, 'C', 1);
    $pdf->Cell(20, 10, 'Status', 1, 0, 'C', 1);
    $pdf->Cell(25, 10, 'User', 1, 0, 'C', 1);
    $pdf->Cell(20, 10, 'Date', 1, 1, 'C', 1);

    // Table data
    $pdf->SetFont('Arial', '', 9);
    foreach ($grievances as $g) {
        $title = $g['title'] ?: 'Untitled';
        $description = substr($g['description'], 0, 100) . (strlen($g['description']) > 100 ? '...' : '');
        $created_at = date('Y-m-d', strtotime($g['created_at']));

        $pdf->Cell(15, 8, $g['id'], 1, 0, 'C');
        $pdf->Cell(30, 8, $title, 1, 0);
        $pdf->Cell(30, 8, $g['category'], 1, 0);
        $pdf->Cell(50, 8, $description, 1, 0);
        $pdf->Cell(20, 8, $g['status'], 1, 0);
        $pdf->Cell(25, 8, $g['user_name'], 1, 0);
        $pdf->Cell(20, 8, $created_at, 1, 1);
    }

    // Output the PDF
    $pdf->Output('D', 'grievance_report.pdf');
    exit;
}
?>
<!DOCTYPE html>
    <?php include '../includes/header.php'; ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Grievance Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .filter-form {
            max-width: 800px;
            margin: 0 auto;
        }
        .table-responsive {
            margin-top: 0px;
        }
    </style>
</head>
<body style="margin-top:-48px">

    <div class="container mt-5">
        <h2 class="mb-4">Generate Grievance Report</h2>
        <div class="filter-form">
            <form method="post" class="mb-4">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="start_date" class="form-label">Start Date</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="end_date" class="form-label">End Date</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="month" class="form-label">Month</label>
                        <input type="month" class="form-control" id="month" name="month" value="<?php echo htmlspecialchars($month); ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="name" class="form-label">User Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" placeholder="Enter partial name">
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">Apply Filters</button>
                        <?php if ($grievances): ?>
                            <button type="submit" name="generate_pdf" class="btn btn-success">Generate PDF</button>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
        <div class="table-responsive">
            <?php if ($grievances): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>User</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($grievances as $g): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($g['id']); ?></td>
                                <td><?php echo htmlspecialchars($g['title'] ?: 'Untitled'); ?></td>
                                <td><?php echo htmlspecialchars($g['category']); ?></td>
                                <td><?php echo htmlspecialchars(substr($g['description'], 0, 100) . (strlen($g['description']) > 100 ? '...' : '')); ?></td>
                                <td><?php echo htmlspecialchars($g['status']); ?></td>
                                <td><?php echo htmlspecialchars($g['user_name']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($g['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-muted">No grievances found for the selected filters.</p>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>