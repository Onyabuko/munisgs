<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $grievance_id = $_POST['grievance_id'];
    $admin_id = $_SESSION['user_id']; // Ensure only logged-in admins can respond
    $message = trim($_POST['message']);

    if (!empty($message)) {
        // Insert the response into the messages table
        $stmt = $pdo->prepare("INSERT INTO messages (grievance_id, sender_id, message) VALUES (?, ?, ?)");
        $stmt->execute([$grievance_id, $admin_id, $message]);

        // Update grievance status to 'solved'
        $updateStmt = $pdo->prepare("UPDATE grievances SET status = 'solved' WHERE id = ?");
        $updateStmt->execute([$grievance_id]);

        echo json_encode(["success" => true, "message" => "Response sent successfully!"]);
    } else {
        echo json_encode(["success" => false, "message" => "Message cannot be empty!"]);
    }
}
?>
