<!DOCTYPE html>
<html lang="en">
<head>
    <title>Counselor Chatbot</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700|Poppins:400,700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" />
    <style>
        /* CSS styles omitted for brevity */
        .chat-container {
            max-width: 600px;
            margin: 0 auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            height: 80vh;
            display: flex;
            flex-direction: column;
        }

        .chat-messages {
            flex: 1;
            padding: 10px;
            overflow-y: auto;
            background-color: #f9f9f9;
        }

        .message {
            margin-bottom: 10px;
            padding: 8px 12px;
            border-radius: 10px;
            max-width: 70%;
        }
        .message h3 {
            color: #333;
            font-size: 1.2em;
        }
        .user-message {
            background-color: #007bff;
            color: white;
            margin-left: auto;
        }
        .bot-message {
            background-color: #e9ecef;
            color: black;
            margin-right: auto;
        }
        .chat-input {
            display: flex;
            border-top: 1px solid #ddd;
            padding: 10px;
            background-color: white;
        }
        .chat-input input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-right: 10px;
        }
        .chat-input button {
            padding: 10px 20px;
            border: none;
            background-color: #007bff;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<?php
include '../includes/config.php';
include '../includes/auth.php'; // Ensure the user is logged in

if(isset($_POST['submit_grievance'])){
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $stmt = $pdo->prepare("INSERT INTO grievances (user_id, title, description) VALUES (?, ?, ?)");
    if($stmt->execute([$_SESSION['user_id'], $title, $description])){
         $_SESSION['message'] = "Grievance submitted successfully!";
         header("Location: dashboard.php");
         exit;
    } else {
         $_SESSION['error'] = "Failed to submit grievance.";
         header("Location: submit.php");
         exit;
    }
}


// Function to save a message to the database
function Message($user_id, $role, $message) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO chat_messages (user_id, role, message) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $role, $message]);
}

if (isset($_POST['submit_grievance'])) {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $stmt = $pdo->prepare("INSERT INTO grievances (user_id, title, description) VALUES (?, ?, ?)");
    if ($stmt->execute([$_SESSION['user_id'], $title, $description])) {
        $_SESSION['message'] = "Grievance submitted successfully!";
        header("Location: dashboard.php");
        exit;
    } else {
        $_SESSION['error'] = "Failed to submit grievance.";
        header("Location: submit.php");
        exit;
    }
}

?>


<?php include '../includes/header.php'; ?>

<!-- Enhanced Navbar -->
<br>
<div class="container mt-5">
    <div class="chat-container">
        <div class="chat-messages" id="chat-messages"></div>
        <div class="chat-input">
            <input type="text" id="user-input" placeholder="Type your message...">
            <button id="send-btn">Send</button>
        </div>
    </div>
</div>

<script>
const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');

const OPENROUTER_API_KEY = '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';
const YOUR_SITE_URL = 'https://munisgs.online';
const YOUR_SITE_NAME = 'Student Grievance System';

// Function to analyze sentiment using an API (e.g., Hugging Face or OpenAI)
async function analyzeSentiment(text) {
    try {
        const response = await fetch('https://api-inference.huggingface.co/models/distilbert-base-uncased-finetuned-sst-2-english', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer 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`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ inputs: text })
        });
        const data = await response.json();
        return data[0][0].label; // Returns 'POSITIVE' or 'NEGATIVE'
    } catch (error) {
        console.error('Error analyzing sentiment:', error);
        return null;
    }
}

function addMessage(role, content) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', role === 'user' ? 'user-message' : 'bot-message');
    messageDiv.textContent = content;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

async function sendMessage() {
    const userMessage = userInput.value.trim();
    if (!userMessage) return;

    addMessage('user', userMessage);
    userInput.value = '';

    try {
        // Analyze sentiment
        const sentiment = await analyzeSentiment(userMessage);
        console.log('Sentiment:', sentiment);

        // Modify bot's response based on sentiment
        let prompt = userMessage;
        if (sentiment === 'NEGATIVE') {
            prompt = `You are an AI assistant for the Student Grievance System at Muni University. Your primary role is to support students by offering compassionate, supportive, and solution-focused responses, as if you are a university counselor. Prioritize clear, respectful communication and provide practical steps to address grievances. When assisting the admin, offer efficient and professional guidance for resolving student issues. Always consider the Ugandan academic and cultural context, using examples relevant to Muni University where appropriate. if the user is feeling negative. Respond empathetically and offer support: "${userMessage}"`;
        } else if (sentiment === 'POSITIVE') {
            prompt = `You are an AI assistant for the Student Grievance System at Muni University. Your primary role is to support students by offering compassionate, supportive, and solution-focused responses, as if you are a university counselor. Prioritize clear, respectful communication and provide practical steps to address grievances. When assisting the admin, offer efficient and professional guidance for resolving student issues. Always consider the Ugandan academic and cultural context, using examples relevant to Muni University where appropriate. if the user is feeling positive. Acknowledge their positivity and encourage them: "${userMessage}"`;
        } else {
            prompt = `You are an AI assistant for the Student Grievance System at Muni University. Your primary role is to support students by offering compassionate, supportive, and solution-focused responses, as if you are a university counselor. Prioritize clear, respectful communication and provide practical steps to address grievances. When assisting the admin, offer efficient and professional guidance for resolving student issues. Always consider the Ugandan academic and cultural context, using examples relevant to Muni University where appropriate. if the user's sentiment is unclear. Respond in a neutral and supportive manner: "${userMessage}"`;
        }

        const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
                'HTTP-Referer': YOUR_SITE_URL,
                'X-Title': YOUR_SITE_NAME,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'deepseek/deepseek-r1:free',
                messages: [{ role: 'user', content: prompt }],
                stream: true // Enable streaming
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        // Create a container for the bot's message
        const botMessageDiv = document.createElement('div');
        botMessageDiv.classList.add('message', 'bot-message');
        chatMessages.appendChild(botMessageDiv);

        // Read the streamed response
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            // Decode the streamed chunk
            const chunk = decoder.decode(value, { stream: true });
            buffer += chunk;

            // Process each line in the buffer
            const lines = buffer.split('\n');
            for (let i = 0; i < lines.length - 1; i++) {
                const line = lines[i].trim();
                if (line.startsWith('data:') && line !== 'data: [DONE]') {
                    try {
                        const json = JSON.parse(line.slice(5)); // Remove 'data:' prefix
                        if (json.choices && json.choices[0].delta.content) {
                            const content = json.choices[0].delta.content;

                            // Replace **xxx..** with <strong>xxx..</strong><br>
                            const processedContent = content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong><br>');

                            // Append the processed content to the bot's message
                            botMessageDiv.innerHTML += processedContent;

                            // Scroll to the bottom of the chat
                            chatMessages.scrollTop = chatMessages.scrollHeight;
                        }
                    } catch (error) {
                        console.error('Error parsing JSON:', error);
                    }
                }
            }

            // Keep the last incomplete line in the buffer
            buffer = lines[lines.length - 1];
        }

        // Finalize the response
        botMessageDiv.innerHTML = botMessageDiv.innerHTML.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong><br>');
        chatMessages.scrollTop = chatMessages.scrollHeight;
    } catch (error) {
        console.error('Error:', error);
        addMessage('bot', 'Sorry, something went wrong. Please try again.');
    }
}

sendBtn.addEventListener('click', sendMessage);
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});
</script>

<!-- Bootstrap and jQuery JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.6/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<?php include '../includes/footer.php'; ?>
</body>
</html>