<?php
// Hash a sample password 'admin123'
$hashedPassword = password_hash('admin@1234', PASSWORD_BCRYPT);
echo $hashedPassword;
?>
