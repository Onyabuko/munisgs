<?php
include 'includes/config.php';
include 'includes/auth.php'; // Ensure the user is logged in

if(isset($_POST['submit_grievance'])){
  $title       = trim($_POST['title']);
  $description = trim($_POST['description']);
  $category    = trim($_POST['category']);
  
  $stmt = $pdo->prepare("INSERT INTO grievances (user_id, title, description, category) VALUES (?, ?, ?, ?)");
  if($stmt->execute([$_SESSION['user_id'], $title, $description, $category])){
       $_SESSION['message'] = "Grievance submitted successfully!";
       header("Location: dashboard.php");
       exit;
  } else {
       $_SESSION['error'] = "Failed to submit grievance.";
       header("Location: submit.php");
       exit;
  }
}
?>

<?php include 'includes/header.php'; ?>
<br><br>
<div class="container min-vh-100 d-flex align-items-center">
  <div class="card mx-auto p-5" style="width: 100%; max-width: 500px;">
    <h2 class="text-center mb-4">Submit Grievance</h2>
    <?php if(isset($_SESSION['error'])): ?>
      <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <form id="submitForm" action="submit.php" method="POST">
      <!-- Title input -->
      <div class="mb-3">
        <input type="text" name="title" class="form-control" placeholder="Enter grievance title" required>
      </div>

      <!-- Category Dropdown -->
      <div class="mb-3">
        <select name="category" class="form-select" required>
          <option value="">Select Category</option>
          <option value="education">Education</option>
          <option value="health">Health</option>
          <option value="bullying">Bullying</option>
          <option value="religious">Religious</option>
          <option value="hostel">Hostel</option>
        </select>
      </div>

      <!-- Description input -->
      <div class="mb-3">
        <textarea name="description" class="form-control" placeholder="Describe your grievance..." rows="5" required></textarea>
      </div>
      <button type="submit" name="submit_grievance" class="btn-gradient w-100">Submit</button>
    </form>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
