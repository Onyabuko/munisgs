<?php
include '../includes/config.php';
include '../includes/auth.php';
include '../includes/helpers.php';

//count unread student messages
$stmt = $pdo->query("
    SELECT COUNT(*) FROM messages m
    JOIN grievances g ON m.grievance_id = g.id
    WHERE m.sender = 'student'
      AND m.is_read = 0
");
$unreadStudentCount = $stmt->fetchColumn();
?>

<!-- Edited Navigation -->
<?php
// Count how many pending
$stmt = $pdo->query("SELECT COUNT(*) FROM grievances WHERE status='pending'");
$pendingCount = $stmt->fetchColumn();
?>

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

<!-- Fixed Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm fixed-top">
  <div class="container-fluid">
    <!-- Brand Logo -->
    <a class="navbar-brand fw-bold" href="../admin/dashboard.php" title="dashboard">
      <i class="fas fa-balance-scale me-2"></i>Student Grievance System (Admin)
    </a>

    <!-- Toggle Button for Mobile -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Navbar Items -->
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto align-items-center">
        <!-- Notification Icon -->
        <li class="nav-item me-3" title="Notifications" >
          <a href="#" class="nav-link position-relative" data-bs-toggle="modal" data-bs-target="#adminNotificationModal"  style="color:white;">
            <i class="fas fa-bell fa-lg"></i>
            <?php if($unreadStudentCount > 0): ?>
              <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                <?php echo $unreadStudentCount; ?>
              </span>
            <?php endif; ?>
          </a>
        </li>

        <!-- Manage Sub-Admins Button (Visible only to Main Admin) -->
        <?php if($_SESSION['user_role'] === 'admin' && $_SESSION['admin_category'] === 'main'): ?>
          <li class="nav-item me-3">
            <a href="manage_subadmins.php" class="btn btn-outline-light">
              <i class="fas fa-users-cog me-2"></i>Manage Sub-Admins
            </a>
          </li>
        <?php endif; ?>

        <!-- Allocate Grievance Button (Visible only to Main Admin) -->
        <?php if($_SESSION['user_role'] === 'admin' && $_SESSION['admin_category'] === 'main'): ?>
          <li class="nav-item me-3">
            <a href="allocate_grievance.php" class="btn btn-outline-light">
              <i class="fas fa-tasks me-2"></i>Allocate Grievance
            </a>
          </li>
        <?php endif; ?>

        <!-- User Dropdown -->
        <li class="nav-item dropdown" title="Logout" >
          <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userMenu" role="button" data-bs-toggle="dropdown" aria-expanded="false"  style="color:white;">
            <i class="fas fa-user-circle me-2 fa-lg"></i>
            <?php echo $_SESSION['user_name']; ?>
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenu" >
            <li><a class="dropdown-item" href="../logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Admin Notifications Modal -->
<div class="modal fade" id="adminNotificationModal" tabindex="-1" aria-labelledby="adminNotificationModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="adminNotificationModalLabel">New Student Messages</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php
        // Fetch unread student messages for all grievances
        $stmt = $pdo->query("
            SELECT m.*, g.title as grievance_title, g.id as grievance_id
            FROM messages m
            JOIN grievances g ON m.grievance_id = g.id
            WHERE m.sender = 'student'
              AND m.is_read = 0
            ORDER BY m.created_at DESC
        ");
        $adminNotifications = $stmt->fetchAll();
        ?>
        <?php if($adminNotifications): ?>
          <ul class="list-group">
            <?php foreach($adminNotifications as $note): ?>
              <li class="list-group-item">
                <a href="../chat.php?grievance_id=<?php echo $note['grievance_id']; ?>">
                  <strong><?php echo htmlspecialchars($note['grievance_title']); ?></strong>
                </a>
                <br>
                <small><?php echo htmlspecialchars(substr($note['message'], 0, 50)); ?>...</small>
                <br>
                <small class="text-muted"><?php echo date('M d, Y H:i', strtotime($note['created_at'])); ?></small>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php else: ?>
          <p class="text-muted">No new notifications.</p>
        <?php endif; ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<br><br>