// Real-time Form Validation
document.querySelectorAll('input').forEach(input => {
    input.addEventListener('input', (e) => {
        if(e.target.checkValidity()) {
            e.target.classList.add('is-valid');
            e.target.classList.remove('is-invalid');
        } else {
            e.target.classList.add('is-invalid');
        }
    });
});

// Animated Loading States
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', (e) => {
        const btn = form.querySelector('button[type="submit"]');
        btn.innerHTML = `<div class="spinner-border spinner-border-sm" role="status"></div> Processing...`;
        btn.disabled = true;
    });
});

// Dynamic Status Badge Colors
function statusColor(status) {
    const colors = {
        'pending': 'warning',
        'in_progress': 'primary',
        'resolved': 'success'
    };
    return colors[status];
}